package exam;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Outcome of one exam attempt: marks scored out of the maximum, percentage and status. */
public class ExamResult {
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final String username;
    private final String studentName;
    private final String examId;
    private final String examTitle;
    private final String timestamp;
    private final int total;        // number of questions
    private final int correct;      // number answered correctly
    private final double score;     // marks obtained (after any negative marking)
    private final double maxScore;  // maximum possible marks

    public ExamResult(String username, String studentName, String examId, String examTitle, String timestamp,
                      int total, int correct, double score, double maxScore) {
        this.username = username;
        this.studentName = studentName;
        this.examId = examId;
        this.examTitle = examTitle;
        this.timestamp = timestamp;
        this.total = total;
        this.correct = correct;
        this.score = score;
        this.maxScore = maxScore;
    }

    public static ExamResult now(String username, String studentName, String examId, String examTitle,
                                 int total, int correct, double score, double maxScore) {
        return new ExamResult(username, studentName, examId, examTitle, LocalDateTime.now().format(FMT),
                total, correct, score, maxScore);
    }

    public String getUsername() { return username; }
    public String getStudentName() { return studentName; }
    public String getExamId() { return examId; }
    public String getExamTitle() { return examTitle; }
    public String getTimestamp() { return timestamp; }
    public int getTotal() { return total; }
    public int getCorrect() { return correct; }
    public double getScore() { return score; }
    public double getMaxScore() { return maxScore; }

    public String getMarksText() {
        return fmt(score) + " / " + fmt(maxScore);
    }

    public double getPercentage() {
        return maxScore <= 0 ? 0 : (score * 100.0) / maxScore;
    }

    public String getStatus() {
        double p = getPercentage();
        if (p >= 80) return "Excellent";
        if (p >= 60) return "Good";
        if (p >= 40) return "Pass";
        return "Fail";
    }

    /** Shows 5 as "5" and 2.5 as "2.50". */
    public static String fmt(double d) {
        return d == Math.rint(d) ? String.valueOf((long) d) : String.format("%.2f", d);
    }

    public String toLine() {
        return String.join("\t", username, studentName.replace("\t", " "), timestamp,
                String.valueOf(total), String.valueOf(correct),
                Double.toString(score), Double.toString(maxScore),
                examId, examTitle.replace("\t", " "));
    }

    /**
     * Reads the current 9-column format and the older 7-, 5- and 4-column formats.
     * Older results had no exam, so they belong to the original exam (General Exam).
     */
    public static ExamResult fromLine(String line) {
        String[] p = line.split("\t", -1);
        try {
            if (p.length == 9) {
                return new ExamResult(p[0], p[1], p[7], p[8], p[2], Integer.parseInt(p[3]), Integer.parseInt(p[4]),
                        Double.parseDouble(p[5]), Double.parseDouble(p[6]));
            }
            if (p.length == 7) {
                return new ExamResult(p[0], p[1], Exam.DEFAULT_ID, Exam.DEFAULT_TITLE, p[2],
                        Integer.parseInt(p[3]), Integer.parseInt(p[4]),
                        Double.parseDouble(p[5]), Double.parseDouble(p[6]));
            }
            if (p.length == 5) {
                int t = Integer.parseInt(p[3]);
                int c = Integer.parseInt(p[4]);
                return new ExamResult(p[0], p[1], Exam.DEFAULT_ID, Exam.DEFAULT_TITLE, p[2], t, c, c, t);
            }
            if (p.length == 4) {
                int t = Integer.parseInt(p[2]);
                int c = Integer.parseInt(p[3]);
                return new ExamResult("", p[0], Exam.DEFAULT_ID, Exam.DEFAULT_TITLE, p[1], t, c, c, t);
            }
        } catch (NumberFormatException e) {
            return null;
        }
        return null;
    }
}
