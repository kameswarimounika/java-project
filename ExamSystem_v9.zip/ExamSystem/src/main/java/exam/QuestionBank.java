package exam;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/** Holds all questions in memory (an ObservableList) and persists them to data/questions.txt. */
public class QuestionBank {
    private static final Path FILE = Paths.get("data", "questions.txt");
    private final ObservableList<Question> questions = FXCollections.observableArrayList();

    public QuestionBank() {
        boolean firstRun = !Files.exists(FILE);
        load();
        if (firstRun && questions.isEmpty()) {      // first run: seed with sample questions
            seed();
            save();
        }
    }

    public ObservableList<Question> getQuestions() { return questions; }

    public void add(Question q) {
        questions.add(q);
        save();
    }

    public void update(Question old, Question q) {
        int index = questions.indexOf(old);
        if (index < 0) return;
        questions.set(index, q);
        save();
    }

    /** Questions that belong to one exam. */
    public List<Question> forExam(String examId) {
        List<Question> list = new ArrayList<>();
        for (Question q : questions) {
            if (q.getExamId().equals(examId)) list.add(q);
        }
        return list;
    }

    public int countFor(String examId) {
        return forExam(examId).size();
    }

    /** Used when the administrator deletes a whole exam. */
    public void removeForExam(String examId) {
        questions.removeIf(q -> q.getExamId().equals(examId));
        save();
    }

    public void remove(Question q) {
        questions.remove(q);
        save();
    }

    private void load() {
        if (!Files.exists(FILE)) return;
        try (BufferedReader r = Files.newBufferedReader(FILE, StandardCharsets.UTF_8)) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.isBlank()) continue;
                Question q = Question.fromLine(line);
                if (q != null) questions.add(q);
            }
        } catch (IOException e) {
            System.err.println("Could not read questions: " + e.getMessage());
        }
    }

    private void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (BufferedWriter w = Files.newBufferedWriter(FILE, StandardCharsets.UTF_8)) {
                for (Question q : questions) {
                    w.write(q.toLine());
                    w.newLine();
                }
            }
        } catch (IOException e) {
            System.err.println("Could not save questions: " + e.getMessage());
        }
    }

    private void seed() {
        questions.add(new Question("Which keyword is used to inherit a class in Java?",
                new String[]{"implements", "extends", "inherits", "super"}, 1, Exam.DEFAULT_ID));
        questions.add(new Question("Which collection does NOT allow duplicate elements?",
                new String[]{"ArrayList", "LinkedList", "HashSet", "Vector"}, 2, Exam.DEFAULT_ID));
        questions.add(new Question("Which method starts a new thread of execution?",
                new String[]{"run()", "start()", "execute()", "begin()"}, 1, Exam.DEFAULT_ID));
        questions.add(new Question("Which JavaFX class is the entry point of an application?",
                new String[]{"Stage", "Scene", "Application", "Platform"}, 2, Exam.DEFAULT_ID));
        questions.add(new Question("Which class is commonly used to read text files line by line?",
                new String[]{"BufferedReader", "PrintStream", "DataOutputStream", "Random"}, 0, Exam.DEFAULT_ID));
    }
}
