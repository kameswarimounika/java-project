package exam;

/** A registered account: either a STUDENT or the ADMIN. Secrets are stored only as salted hashes. */
public class User {
    public static final String ADMIN = "ADMIN";
    public static final String STUDENT = "STUDENT";

    private final String username;
    private final String fullName;
    private final String passwordHash;   // "salt$hash"
    private final String role;
    private final String question;       // security question (plain text)
    private final String answerHash;     // "salt$hash" of the normalised answer

    public User(String username, String fullName, String passwordHash, String role,
                String question, String answerHash) {
        this.username = username;
        this.fullName = fullName;
        this.passwordHash = passwordHash;
        this.role = role;
        this.question = question;
        this.answerHash = answerHash;
    }

    public String getUsername() { return username; }
    public String getFullName() { return fullName; }
    public String getPasswordHash() { return passwordHash; }
    public String getRole() { return role; }
    public String getQuestion() { return question; }
    public String getAnswerHash() { return answerHash; }
    public boolean isAdmin() { return ADMIN.equals(role); }

    public User withPasswordHash(String newHash) {
        return new User(username, fullName, newHash, role, question, answerHash);
    }

    public String toLine() {
        return String.join("\t", username, fullName.replace("\t", " "), passwordHash, role,
                question.replace("\t", " "), answerHash);
    }

    /** Returns null for malformed or old-format lines. */
    public static User fromLine(String line) {
        String[] p = line.split("\t", -1);
        if (p.length != 6) return null;
        return new User(p[0], p[1], p[2], p[3], p[4], p[5]);
    }
}
