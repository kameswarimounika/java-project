package exam;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

/** All exams, stored in data/exams.txt. */
public class ExamStore {
    private static final Path FILE = Paths.get("data", "exams.txt");
    private static final Path SEQ = Paths.get("data", "exams.seq");
    private final List<Exam> exams = new ArrayList<>();

    /**
     * On the very first run with this version, the old single exam (data/settings.txt plus every existing
     * question and result) becomes the exam "General Exam", so nothing from v8 is lost.
     */
    public ExamStore(ExamSettings legacy) {
        boolean firstRun = !Files.exists(FILE);
        load();
        if (firstRun) {
            exams.add(new Exam(Exam.DEFAULT_ID, Exam.DEFAULT_TITLE, "General", Exam.TYPES[0], "",
                    legacy.getDurationMinutes(), legacy.getMarksPerQuestion(),
                    legacy.getNegativeMarks(), legacy.getQuestionsPerExam(), null, null));
            save();
        }
    }

    public List<Exam> all() {
        return new ArrayList<>(exams);
    }

    public Exam find(String id) {
        for (Exam e : exams) {
            if (e.getId().equals(id)) return e;
        }
        return null;
    }

    /** Adds an exam, giving it a fresh id. Returns the saved exam. */
    public Exam add(Exam e) {
        Exam saved = e.withId(nextId());
        exams.add(saved);
        save();
        return saved;
    }

    public void update(Exam e) {
        for (int i = 0; i < exams.size(); i++) {
            if (exams.get(i).getId().equals(e.getId())) {
                exams.set(i, e);
                save();
                return;
            }
        }
    }

    public void remove(String id) {
        exams.removeIf(e -> e.getId().equals(id));
        save();
    }

    /**
     * Ids are never reused, even after an exam is deleted: old results and attempts are filed under the id,
     * so a recycled id would make a brand-new exam look "already attempted". The last number used is
     * remembered in data/exams.seq.
     */
    private String nextId() {
        int max = 0;
        for (Exam e : exams) max = Math.max(max, numberOf(e.getId()));
        try {
            if (Files.exists(SEQ)) {
                max = Math.max(max, Integer.parseInt(Files.readString(SEQ, StandardCharsets.UTF_8).trim()));
            }
        } catch (IOException | NumberFormatException ignored) {
            // fall back to the highest id in use
        }
        int next = max + 1;
        try {
            Files.createDirectories(SEQ.getParent());
            Files.writeString(SEQ, String.valueOf(next), StandardCharsets.UTF_8);
        } catch (IOException ex) {
            System.err.println("Could not save exam counter: " + ex.getMessage());
        }
        return "E" + next;
    }

    private static int numberOf(String id) {
        if (id.length() > 1 && id.charAt(0) == 'E') {
            try {
                return Integer.parseInt(id.substring(1));
            } catch (NumberFormatException ignored) {
                // not one of our ids
            }
        }
        return 0;
    }

    private void load() {
        if (!Files.exists(FILE)) return;
        try {
            for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
                if (line.isBlank()) continue;
                Exam e = Exam.fromLine(line);
                if (e != null) exams.add(e);
            }
        } catch (IOException ex) {
            System.err.println("Could not read exams: " + ex.getMessage());
        }
    }

    private void save() {
        try {
            Files.createDirectories(FILE.getParent());
            List<String> lines = new ArrayList<>();
            for (Exam e : exams) lines.add(e.toLine());
            Files.write(FILE, lines, StandardCharsets.UTF_8);
        } catch (IOException ex) {
            System.err.println("Could not save exams: " + ex.getMessage());
        }
    }
}
