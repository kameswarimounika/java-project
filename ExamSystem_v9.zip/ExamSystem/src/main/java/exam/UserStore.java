package exam;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Accounts stored in data/users.txt.
 * Passwords and security answers are saved only as salted PBKDF2 hashes (never plain text).
 * Repeated wrong attempts lock the account name for a short time.
 */
public class UserStore {
    public static final List<String> QUESTIONS = List.of(
            "What is the name of your first school?",
            "What is your favourite teacher's name?",
            "In which city were you born?",
            "What was the name of your first pet?",
            "What is your favourite book?");

    private static final Path FILE = Paths.get("data", "users.txt");
    private static final int MAX_FAILURES = 3;
    private static final long LOCK_MILLIS = 30_000;

    private final List<User> users = new ArrayList<>();
    private final Map<String, Integer> failures = new HashMap<>();
    private final Map<String, Long> lockedUntil = new HashMap<>();
    private static final SecureRandom RANDOM = new SecureRandom();

    public UserStore() {
        load();
    }

    public boolean hasAdmin() {
        for (User u : users) {
            if (u.isAdmin()) return true;
        }
        return false;
    }

    public User find(String username) {
        for (User u : users) {
            if (u.getUsername().equalsIgnoreCase(username)) return u;
        }
        return null;
    }

    // ------------------------------------------------------------------
    // Login and lockout
    // ------------------------------------------------------------------
    /** Returns the user if the credentials are correct, otherwise null. */
    public User authenticate(String username, String password) {
        User u = find(username);
        if (u != null && matches(password, u.getPasswordHash())) return u;
        return null;
    }

    /** Seconds the given key (a username) is still locked for; 0 if not locked. */
    public long lockSecondsLeft(String key) {
        String k = key.toLowerCase();
        Long until = lockedUntil.get(k);
        if (until == null) return 0;
        long left = until - System.currentTimeMillis();
        if (left <= 0) {
            lockedUntil.remove(k);
            return 0;
        }
        return (left + 999) / 1000;
    }

    public void recordFailure(String key) {
        String k = key.toLowerCase();
        int n = failures.merge(k, 1, Integer::sum);
        if (n >= MAX_FAILURES) {
            lockedUntil.put(k, System.currentTimeMillis() + LOCK_MILLIS);
            failures.remove(k);
        }
    }

    public void clearFailures(String key) {
        String k = key.toLowerCase();
        failures.remove(k);
        lockedUntil.remove(k);
    }

    // ------------------------------------------------------------------
    // Registration
    // ------------------------------------------------------------------
    public String registerStudent(String fullName, String username, String password,
                                  String question, String answer) {
        return create(fullName, username, password, question, answer, User.STUDENT);
    }

    /** Only works while no administrator exists (first-time setup). */
    public String registerAdmin(String fullName, String username, String password,
                                String question, String answer) {
        if (hasAdmin()) return "An administrator already exists.";
        return create(fullName, username, password, question, answer, User.ADMIN);
    }

    private String create(String fullName, String username, String password,
                          String question, String answer, String role) {
        fullName = fullName.trim();
        username = username.trim();
        answer = normalise(answer);
        if (fullName.isEmpty()) return "Please enter your full name.";
        if (!username.matches("[A-Za-z0-9_]{3,20}"))
            return "Username must be 3-20 characters: letters, digits or underscore.";
        String pwError = checkPassword(password);
        if (pwError != null) return pwError;
        if (question == null || !QUESTIONS.contains(question)) return "Please choose a security question.";
        if (answer.length() < 2) return "Please enter an answer to the security question.";
        if (find(username) != null) return "That username is already taken.";
        users.add(new User(username, fullName.replace("\t", " "), protect(password), role,
                question, protect(answer)));
        save();
        return null;
    }

    /** Password rule: at least 6 characters with letters and digits. Returns an error or null. */
    public static String checkPassword(String pw) {
        if (pw.length() < 6) return "Password must be at least 6 characters.";
        boolean letter = false, digit = false;
        for (char c : pw.toCharArray()) {
            if (Character.isLetter(c)) letter = true;
            if (Character.isDigit(c)) digit = true;
        }
        if (!letter || !digit) return "Password must contain both letters and digits.";
        return null;
    }

    // ------------------------------------------------------------------
    // Forgot / change password
    // ------------------------------------------------------------------
    /** The user's security question, or null if the username does not exist. */
    public String getSecurityQuestion(String username) {
        User u = find(username);
        return u == null ? null : u.getQuestion();
    }

    /** Resets the password if the security answer is right. Returns an error or null. */
    public String resetPassword(String username, String answer, String newPassword) {
        String key = "reset:" + username.toLowerCase();
        long wait = lockSecondsLeft(key);
        if (wait > 0) return "Too many wrong answers. Try again in " + wait + " seconds.";
        User u = find(username);
        if (u == null) return "No account found.";
        if (!matches(normalise(answer), u.getAnswerHash())) {
            recordFailure(key);
            return "Incorrect answer.";
        }
        String pwError = checkPassword(newPassword);
        if (pwError != null) return pwError;
        replace(u, u.withPasswordHash(protect(newPassword)));
        clearFailures(key);
        return null;
    }

    /** Changes the password of a logged-in user. Returns an error or null. */
    public String changePassword(String username, String oldPassword, String newPassword) {
        User u = find(username);
        if (u == null || !matches(oldPassword, u.getPasswordHash())) return "Current password is incorrect.";
        String pwError = checkPassword(newPassword);
        if (pwError != null) return pwError;
        replace(u, u.withPasswordHash(protect(newPassword)));
        return null;
    }

    // ------------------------------------------------------------------
    // Administrator tools (the caller must check that the user is an admin)
    // ------------------------------------------------------------------
    public List<User> all() {
        return new ArrayList<>(users);
    }

    /** Adds another administrator account. Returns an error or null. */
    public String addAdmin(String fullName, String username, String password,
                           String question, String answer) {
        return create(fullName, username, password, question, answer, User.ADMIN);
    }

    /** Deletes an account. An administrator cannot delete their own account. */
    public String deleteUser(String username, String actingUsername) {
        if (username.equalsIgnoreCase(actingUsername)) return "You cannot delete your own account.";
        User u = find(username);
        if (u == null) return "Account not found.";
        users.remove(u);
        save();
        return null;
    }

    /** Sets a new password for any account (for students who forgot their security answer). */
    public String adminResetPassword(String username, String newPassword) {
        User u = find(username);
        if (u == null) return "Account not found.";
        String pwError = checkPassword(newPassword);
        if (pwError != null) return pwError;
        replace(u, u.withPasswordHash(protect(newPassword)));
        clearFailures(username);
        clearFailures("reset:" + username);
        return null;
    }

    private void replace(User old, User updated) {
        users.set(users.indexOf(old), updated);
        save();
    }

    // ------------------------------------------------------------------
    // Hashing (salted PBKDF2)
    // ------------------------------------------------------------------
    private static String normalise(String s) {
        return s.trim().toLowerCase().replaceAll("\\s+", " ");
    }

    private static String derive(String secret, byte[] salt) {
        try {
            PBEKeySpec spec = new PBEKeySpec(secret.toCharArray(), salt, 65536, 256);
            SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
            return Base64.getEncoder().encodeToString(f.generateSecret(spec).getEncoded());
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Returns "salt$hash" with a fresh random salt. */
    private static String protect(String secret) {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt) + "$" + derive(secret, salt);
    }

    private static boolean matches(String secret, String stored) {
        try {
            String[] p = stored.split("\\$");
            if (p.length != 2) return false;
            byte[] salt = Base64.getDecoder().decode(p[0]);
            byte[] expected = p[1].getBytes(StandardCharsets.UTF_8);
            byte[] actual = derive(secret, salt).getBytes(StandardCharsets.UTF_8);
            return MessageDigest.isEqual(expected, actual);
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

    // ------------------------------------------------------------------
    // File handling
    // ------------------------------------------------------------------
    private void load() {
        if (!Files.exists(FILE)) return;
        try {
            for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
                if (line.isBlank()) continue;
                User u = User.fromLine(line);
                if (u != null) users.add(u);
            }
        } catch (IOException e) {
            System.err.println("Could not read users: " + e.getMessage());
        }
    }

    private void save() {
        try {
            Files.createDirectories(FILE.getParent());
            List<String> lines = new ArrayList<>();
            for (User u : users) lines.add(u.toLine());
            Files.write(FILE, lines, StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.err.println("Could not save users: " + e.getMessage());
        }
    }
}
