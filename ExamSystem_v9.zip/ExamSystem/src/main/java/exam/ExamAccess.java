package exam;

import java.time.LocalDateTime;

/** Where one exam stands for one student. This is the single place that decides "can this student start it?". */
public enum ExamAccess {
    OPEN, UPCOMING, CLOSED, ATTEMPTED, INTERRUPTED, NO_QUESTIONS;

    /**
     * @param hasResult     the student already has a saved result for this exam
     * @param started       the student already started it once (recorded before the first question is shown)
     * @param questionCount questions available for this exam
     */
    public static ExamAccess of(Exam exam, boolean hasResult, boolean started, int questionCount, LocalDateTime now) {
        if (hasResult) return ATTEMPTED;
        if (started) return INTERRUPTED;
        if (questionCount <= 0) return NO_QUESTIONS;
        if (exam.getStart() != null && now.isBefore(exam.getStart())) return UPCOMING;
        if (exam.getEnd() != null && now.isAfter(exam.getEnd())) return CLOSED;
        return OPEN;
    }

    public boolean canStart() {
        return this == OPEN;
    }

    /** Why the exam cannot be started (shown in a pop-up). */
    public String message() {
        return switch (this) {
            case OPEN -> "";
            case UPCOMING -> "This exam has not opened yet.";
            case CLOSED -> "This exam is closed.";
            case ATTEMPTED -> "You have already written this exam. Each exam can be attempted only once.";
            case INTERRUPTED -> "You already started this exam earlier, and it was not completed. "
                    + "Each exam can be attempted only once, so please contact your faculty.";
            case NO_QUESTIONS -> "This exam has no questions yet.";
        };
    }
}
