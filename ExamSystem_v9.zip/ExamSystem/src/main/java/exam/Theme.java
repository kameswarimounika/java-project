package exam;

import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.animation.RotateTransition;
import javafx.animation.TranslateTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.geometry.VPos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.GaussianBlur;
import javafx.scene.image.Image;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.util.Duration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Shared look and feel: gradient background, floating blurred blobs, glass cards, glowing buttons. */
public final class Theme {
    public static final String FONT = "-fx-font-family: 'Segoe UI', Arial, sans-serif;";

    private static final String FIELD = FONT
            + "-fx-background-color:#f3f4f6;-fx-background-radius:10;-fx-border-color:#c7d2fe;"
            + "-fx-border-radius:10;-fx-padding:9 12 9 12;-fx-font-size:14px;";

    /** Background animations currently running; stopped when the next screen is built. */
    private static final List<Animation> running = new ArrayList<>();

    private Theme() { }

    // ------------------------------------------------------------------
    // Background
    // ------------------------------------------------------------------
    /** Stops the floating background animations (used by full-window screens that have no background). */
    public static void stopAnimations() {
        for (Animation a : running) a.stop();
        running.clear();
    }

    public static StackPane background(Node content) {
        stopAnimations();

        Image photo = photo();
        if (photo != null) {            // user-supplied picture: assets/background.jpg or .png
            Region pic = new Region();
            pic.setBackground(new Background(new BackgroundImage(photo,
                    BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER,
                    new BackgroundSize(100, 100, true, true, false, true))));
            return new StackPane(pic, content);
        }

        Region gradient = new Region();
        gradient.setStyle("-fx-background-color: linear-gradient(to bottom right, #0f2c67, #2a5298 50%, #5b86e5);");

        Pane blobs = new Pane();
        blobs.setMouseTransparent(true);
        blobs.getChildren().addAll(
                blob(130, "#ff6ec7", 0.40, 120, 110, 90, 60, 8),
                blob(170, "#22d3ee", 0.40, 820, 140, -100, 70, 10),
                blob(120, "#f9d423", 0.30, 380, 560, 80, -80, 9),
                blob(150, "#a78bfa", 0.40, 880, 560, -90, -60, 11));
        blobs.setEffect(new GaussianBlur(60));

        return new StackPane(gradient, blobs, examIcons(), content);
    }

    private static Image cachedPhoto;
    private static boolean photoChecked;

    /** Loads assets/background.jpg (or .jpeg / .png) once; returns null if there is none. */
    private static Image photo() {
        if (!photoChecked) {
            photoChecked = true;
            for (String name : new String[]{"background.jpg", "background.jpeg", "background.png"}) {
                File f = new File("assets", name);
                if (f.isFile()) {
                    Image img = new Image(f.toURI().toString());
                    if (!img.isError()) {
                        cachedPhoto = img;
                        break;
                    }
                }
            }
        }
        return cachedPhoto;
    }

    // ------------------------------------------------------------------
    // Exam-themed decorations: answer sheets, pencil, clock, graduation cap, grade text
    // ------------------------------------------------------------------
    private static Pane examIcons() {
        Pane p = new Pane();
        p.setMouseTransparent(true);
        place(p, paper(), 0.03, 0.06, -14, 0.35, 9);
        place(p, paper(), 0.88, 0.58, 12, 0.30, 11);
        place(p, pencil(), 0.78, 0.07, 25, 0.40, 10);
        place(p, clock(), 0.09, 0.80, 0, 0.35, 12);
        place(p, cap(), 0.90, 0.30, -8, 0.35, 13);
        place(p, bigText("A+", 72), 0.10, 0.40, -10, 0.30, 10);
        place(p, bigText("MCQ", 46), 0.05, 0.62, 8, 0.28, 12);
        place(p, bigText("?", 90), 0.84, 0.82, 12, 0.28, 11);
        return p;
    }

    /** Positions a decoration relative to the window size and makes it float gently. */
    private static void place(Pane p, Node n, double fx, double fy, double angle, double opacity, double seconds) {
        n.setRotate(angle);
        n.setOpacity(opacity);
        n.layoutXProperty().bind(p.widthProperty().multiply(fx));
        n.layoutYProperty().bind(p.heightProperty().multiply(fy));
        p.getChildren().add(n);

        TranslateTransition t = new TranslateTransition(Duration.seconds(seconds), n);
        t.setByY(18);
        t.setAutoReverse(true);
        t.setCycleCount(Animation.INDEFINITE);
        t.play();
        running.add(t);

        RotateTransition r = new RotateTransition(Duration.seconds(seconds * 1.3), n);
        r.setByAngle(8);
        r.setAutoReverse(true);
        r.setCycleCount(Animation.INDEFINITE);
        r.play();
        running.add(r);
    }

    /** An OMR-style answer sheet with bubbles. */
    private static Group paper() {
        Rectangle sheet = new Rectangle(120, 150);
        sheet.setArcWidth(14);
        sheet.setArcHeight(14);
        sheet.setFill(Color.WHITE);
        sheet.setStroke(Color.web("#c7d2fe"));
        sheet.setStrokeWidth(2);
        Group g = new Group(sheet);
        for (int i = 0; i < 4; i++) {
            double y = 28 + i * 30;
            Circle bubble = new Circle(24, y, 8);
            bubble.setFill(i == 1 ? Color.web("#22c55e") : Color.TRANSPARENT);
            bubble.setStroke(Color.web("#6366f1"));
            bubble.setStrokeWidth(2);
            Rectangle line = new Rectangle(42, y - 3, 58, 6);
            line.setArcWidth(6);
            line.setArcHeight(6);
            line.setFill(Color.web("#c7d2fe"));
            g.getChildren().addAll(bubble, line);
        }
        return g;
    }

    private static Group pencil() {
        Rectangle eraser = new Rectangle(0, 0, 18, 18);
        eraser.setFill(Color.web("#f472b6"));
        Rectangle body = new Rectangle(18, 0, 90, 18);
        body.setFill(Color.web("#fbbf24"));
        Rectangle band = new Rectangle(18, 0, 8, 18);
        band.setFill(Color.web("#9ca3af"));
        Polygon tip = new Polygon(108, 0, 134, 9, 108, 18);
        tip.setFill(Color.web("#fde7c3"));
        Polygon lead = new Polygon(126, 6, 134, 9, 126, 12);
        lead.setFill(Color.web("#1f2937"));
        return new Group(eraser, body, band, tip, lead);
    }

    private static Group clock() {
        Circle face = new Circle(0, 0, 42);
        face.setFill(Color.WHITE);
        face.setStroke(Color.web("#6366f1"));
        face.setStrokeWidth(6);
        Line minute = new Line(0, 0, 0, -26);
        minute.setStroke(Color.web("#1f2937"));
        minute.setStrokeWidth(4);
        Line hour = new Line(0, 0, 20, 0);
        hour.setStroke(Color.web("#1f2937"));
        hour.setStrokeWidth(4);
        Circle pin = new Circle(0, 0, 4, Color.web("#1f2937"));
        return new Group(face, minute, hour, pin);
    }

    private static Group cap() {
        Polygon base = new Polygon(-34, 14, 0, 30, 34, 14, 34, 40, 0, 54, -34, 40);
        base.setFill(Color.web("#1f2937"));
        Polygon top = new Polygon(-60, 0, 0, -26, 60, 0, 0, 26);
        top.setFill(Color.web("#111827"));
        Line cord = new Line(60, 0, 60, 34);
        cord.setStroke(Color.web("#fbbf24"));
        cord.setStrokeWidth(3);
        Circle tassel = new Circle(60, 38, 5, Color.web("#fbbf24"));
        return new Group(base, top, cord, tassel);
    }

    private static Text bigText(String s, double size) {
        Text t = new Text(s);
        t.setFont(Font.font("Segoe UI", FontWeight.BOLD, size));
        t.setFill(Color.WHITE);
        t.setTextOrigin(VPos.TOP);
        return t;
    }

    private static Circle blob(double radius, String color, double opacity,
                               double x, double y, double dx, double dy, double seconds) {
        Circle c = new Circle(x, y, radius, Color.web(color, opacity));
        TranslateTransition t = new TranslateTransition(Duration.seconds(seconds), c);
        t.setByX(dx);
        t.setByY(dy);
        t.setAutoReverse(true);
        t.setCycleCount(Animation.INDEFINITE);
        t.play();
        running.add(t);
        return c;
    }

    public static void fadeIn(Node n) {
        FadeTransition ft = new FadeTransition(Duration.millis(450), n);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();
    }

    // ------------------------------------------------------------------
    // Containers and text
    // ------------------------------------------------------------------
    public static VBox card(double maxWidth, Node... children) {
        VBox card = new VBox(14, children);
        card.setAlignment(Pos.TOP_CENTER);
        card.setPadding(new Insets(28));
        card.setMaxWidth(maxWidth);
        card.setMaxHeight(Region.USE_PREF_SIZE);
        card.setStyle("-fx-background-color: rgba(255,255,255,0.96); -fx-background-radius: 22;"
                + "-fx-border-color: rgba(79,70,229,0.35); -fx-border-radius: 22; -fx-border-width: 2;");
        card.setEffect(new DropShadow(35, 0, 10, Color.rgb(0, 0, 0, 0.45)));
        return card;
    }

    public static Label title(String text) {
        Label l = new Label(text);
        l.setStyle(FONT + "-fx-font-size:26px;-fx-font-weight:bold;-fx-text-fill:#1f2937;");
        l.setMaxWidth(Double.MAX_VALUE);
        l.setAlignment(Pos.CENTER);
        return l;
    }

    public static Label subtitle(String text) {
        Label l = new Label(text);
        l.setStyle(FONT + "-fx-font-size:14px;-fx-text-fill:#6b7280;");
        l.setWrapText(true);
        l.setMaxWidth(Double.MAX_VALUE);
        l.setAlignment(Pos.CENTER);
        return l;
    }

    // ------------------------------------------------------------------
    // Inputs
    // ------------------------------------------------------------------
    public static TextField field(String prompt) {
        TextField t = new TextField();
        t.setPromptText(prompt);
        t.setStyle(FIELD);
        return t;
    }

    public static PasswordField passwordField(String prompt) {
        PasswordField p = new PasswordField();
        p.setPromptText(prompt);
        p.setStyle(FIELD);
        return p;
    }

    // ------------------------------------------------------------------
    // Buttons
    // ------------------------------------------------------------------
    public static Button primary(String text) {
        return styled(text, "linear-gradient(to right, #667eea, #764ba2)");
    }

    public static Button success(String text) {
        return styled(text, "linear-gradient(to right, #11998e, #38ef7d)");
    }

    public static Button danger(String text) {
        return styled(text, "linear-gradient(to right, #cb2d3e, #ef473a)");
    }

    public static Button secondary(String text) {
        return styled(text, "linear-gradient(to right, #757f9a, #5f6b87)");
    }

    public static Button link(String text) {
        Button b = new Button(text);
        b.setStyle(FONT + "-fx-background-color:transparent;-fx-text-fill:#4f46e5;"
                + "-fx-underline:true;-fx-cursor:hand;-fx-font-size:13px;");
        return b;
    }

    private static Button styled(String text, String gradient) {
        Button b = new Button(text);
        b.setStyle(FONT + "-fx-background-color:" + gradient + ";-fx-text-fill:white;-fx-font-size:14px;"
                + "-fx-font-weight:bold;-fx-background-radius:22;-fx-padding:10 24 10 24;-fx-cursor:hand;");
        DropShadow shadow = new DropShadow(10, 0, 3, Color.rgb(0, 0, 0, 0.3));
        b.setEffect(shadow);
        b.setOnMouseEntered(e -> {
            b.setScaleX(1.05);
            b.setScaleY(1.05);
            shadow.setRadius(18);
        });
        b.setOnMouseExited(e -> {
            b.setScaleX(1.0);
            b.setScaleY(1.0);
            shadow.setRadius(10);
        });
        return b;
    }
}
