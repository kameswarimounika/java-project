package exam;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.SVGPath;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.function.Consumer;

/**
 * The student's home screen: one card per exam, so the student always knows which exam they are starting.
 * Each card shows type, subject, title, status, duration, number of questions and the faculty.
 * An exam that has been written shows "Review" instead of "Start", so it can never be started twice.
 */
public class StudentDashboard {
    private static final String PURPLE = "#6b2f7f";
    private static final String LAVENDER = "#eadcf0";
    private static final String PAGE = "#faf7f2";
    private static final String MONO = "-fx-font-family:'Consolas','Courier New',monospace;";

    private record Row(Exam exam, ExamAccess access, ExamResult result, int questions) { }

    private final User user;
    private final List<Row> rows = new ArrayList<>();
    private final Consumer<Exam> onStart;
    private final Consumer<ExamResult> onReview;
    private final Runnable onResults;
    private final Runnable onPassword;
    private final Runnable onLogout;

    private final VBox cards = new VBox(14);
    private final Button[] chips = new Button[3];
    private final String[] chipKeys = {"ALL", "TODO", "PAST"};
    private String filter = "ALL";
    private final LocalDateTime now = LocalDateTime.now();

    public StudentDashboard(User user, List<Exam> exams, QuestionBank bank, List<ExamResult> mine,
                            Set<String> started, Consumer<Exam> onStart, Consumer<ExamResult> onReview,
                            Runnable onResults, Runnable onPassword, Runnable onLogout) {
        this.user = user;
        this.onStart = onStart;
        this.onReview = onReview;
        this.onResults = onResults;
        this.onPassword = onPassword;
        this.onLogout = onLogout;

        for (int i = exams.size() - 1; i >= 0; i--) {            // newest exam first
            Exam e = exams.get(i);
            ExamResult result = null;
            for (ExamResult x : mine) {
                if (x.getExamId().equals(e.getId())) result = x;
            }
            int total = bank.countFor(e.getId());
            ExamAccess access = ExamAccess.of(e, result != null, started.contains(e.getId()), total, now);
            if (access == ExamAccess.NO_QUESTIONS) continue;      // the administrator is still setting it up
            int n = e.getQuestionsPerExam();
            rows.add(new Row(e, access, result, (n > 0 && n < total) ? n : total));
        }
        rows.sort((a, b) -> Integer.compare(rank(a.access()), rank(b.access())));   // stable: keeps newest first
    }

    /** Open exams first, finished ones last. */
    private static int rank(ExamAccess a) {
        return switch (a) {
            case OPEN -> 0;
            case UPCOMING -> 1;
            case INTERRUPTED -> 2;
            case CLOSED -> 3;
            case ATTEMPTED -> 4;
            case NO_QUESTIONS -> 5;
        };
    }

    public Region build() {
        Node header = header();
        ScrollPane body = body();
        VBox root = new VBox(header, body);
        VBox.setVgrow(body, Priority.ALWAYS);
        root.setStyle(Theme.FONT + "-fx-background-color:" + PAGE + ";");
        return root;
    }

    // ------------------------------------------------------------------
    // Header bar
    // ------------------------------------------------------------------
    private Node header() {
        String name = user.getFullName().isBlank() ? user.getUsername() : user.getFullName();
        Label avatar = new Label(name.substring(0, 1).toUpperCase());
        avatar.setMinSize(46, 46);
        avatar.setMaxSize(46, 46);
        avatar.setAlignment(Pos.CENTER);
        avatar.setStyle("-fx-background-color:rgba(255,255,255,0.18);-fx-background-radius:13;"
                + "-fx-border-color:rgba(255,255,255,0.4);-fx-border-radius:13;"
                + "-fx-text-fill:white;-fx-font-size:21px;-fx-font-weight:bold;");

        Label app = new Label("Smart Online Exam");
        app.setStyle("-fx-text-fill:white;-fx-font-size:20px;-fx-font-weight:bold;");
        Label hello = new Label("Welcome, " + name);
        hello.setStyle("-fx-text-fill:rgba(255,255,255,0.8);-fx-font-size:13px;");
        VBox titles = new VBox(2, app, hello);

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Button results = headerButton("My Results");
        Button password = headerButton("Password");
        Button logout = headerButton("Logout");
        results.setOnAction(e -> onResults.run());
        password.setOnAction(e -> onPassword.run());
        logout.setOnAction(e -> onLogout.run());

        HBox bar = new HBox(12, avatar, titles, spacer, results, password, logout);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(16, 24, 16, 24));
        bar.setStyle("-fx-background-color:" + PURPLE + ";");
        bar.setEffect(new DropShadow(10, 0, 3, Color.rgb(0, 0, 0, 0.25)));
        return bar;
    }

    private Button headerButton(String text) {
        Button b = new Button(text);
        b.setStyle("-fx-background-color:rgba(255,255,255,0.14);-fx-text-fill:white;-fx-font-size:13px;"
                + "-fx-font-weight:bold;-fx-background-radius:12;-fx-border-color:rgba(255,255,255,0.35);"
                + "-fx-border-radius:12;-fx-padding:8 16 8 16;-fx-cursor:hand;");
        return b;
    }

    // ------------------------------------------------------------------
    // Body: summary tiles, filter chips, exam cards
    // ------------------------------------------------------------------
    private ScrollPane body() {
        VBox content = new VBox(16, stats(), sectionRow(), cards);
        content.setMaxWidth(820);
        content.setPadding(new Insets(20, 24, 28, 24));

        HBox center = new HBox(content);
        center.setAlignment(Pos.TOP_CENTER);
        HBox.setHgrow(content, Priority.ALWAYS);

        ScrollPane sp = new ScrollPane(center);
        sp.setFitToWidth(true);
        sp.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        sp.setStyle("-fx-background:" + PAGE + ";-fx-background-color:" + PAGE + ";");
        refreshCards();
        return sp;
    }

    private Node stats() {
        int todo = 0, done = 0;
        double sum = 0;
        for (Row r : rows) {
            if (r.access() == ExamAccess.OPEN || r.access() == ExamAccess.UPCOMING) todo++;
            if (r.access() == ExamAccess.ATTEMPTED) {
                done++;
                sum += r.result().getPercentage();
            }
        }
        String avg = done == 0 ? "-" : String.format("%.0f%%", sum / done);
        HBox row = new HBox(12, tile("TO DO", String.valueOf(todo)), tile("COMPLETED", String.valueOf(done)),
                tile("AVERAGE SCORE", avg));
        return row;
    }

    private Node tile(String label, String value) {
        Label l = new Label(label);
        l.setStyle(MONO + "-fx-font-size:11px;-fx-font-weight:bold;-fx-text-fill:#8b7f93;");
        Label v = new Label(value);
        v.setStyle("-fx-font-size:26px;-fx-font-weight:bold;-fx-text-fill:" + PURPLE + ";");
        VBox box = new VBox(2, l, v);
        box.setPadding(new Insets(12, 16, 12, 16));
        box.setMaxWidth(Double.MAX_VALUE);
        HBox.setHgrow(box, Priority.ALWAYS);
        box.setStyle(cardStyle());
        return box;
    }

    private Node sectionRow() {
        Label title = new Label("FROM YOUR FACULTY");
        title.setStyle(MONO + "-fx-font-size:13px;-fx-font-weight:bold;-fx-text-fill:#6b6270;");
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox row = new HBox(8, title, spacer);
        row.setAlignment(Pos.CENTER_LEFT);
        String[] labels = {"All", "To do", "Past"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            chips[i] = new Button(labels[i]);
            chips[i].setOnAction(e -> {
                filter = chipKeys[idx];
                styleChips();
                refreshCards();
            });
            row.getChildren().add(chips[i]);
        }
        styleChips();
        return row;
    }

    private void styleChips() {
        for (int i = 0; i < 3; i++) {
            boolean on = chipKeys[i].equals(filter);
            chips[i].setStyle("-fx-background-radius:14;-fx-padding:5 14 5 14;-fx-font-size:12px;"
                    + "-fx-font-weight:bold;-fx-cursor:hand;"
                    + "-fx-background-color:" + (on ? PURPLE : LAVENDER) + ";"
                    + "-fx-text-fill:" + (on ? "white" : PURPLE) + ";");
        }
    }

    private boolean matches(Row r) {
        boolean todo = r.access() == ExamAccess.OPEN || r.access() == ExamAccess.UPCOMING;
        return switch (filter) {
            case "TODO" -> todo;
            case "PAST" -> !todo;
            default -> true;
        };
    }

    private void refreshCards() {
        cards.getChildren().clear();
        for (Row r : rows) {
            if (matches(r)) cards.getChildren().add(card(r));
        }
        if (cards.getChildren().isEmpty()) {
            Label none = new Label(rows.isEmpty()
                    ? "No exams have been published yet. Please check back later."
                    : "No exams in this list.");
            none.setStyle("-fx-font-size:14px;-fx-text-fill:#8b7f93;-fx-padding:30 0 30 0;");
            none.setMaxWidth(Double.MAX_VALUE);
            none.setAlignment(Pos.CENTER);
            cards.getChildren().add(none);
        }
    }

    // ------------------------------------------------------------------
    // One exam card
    // ------------------------------------------------------------------
    private Node card(Row r) {
        Exam e = r.exam();
        ExamAccess a = r.access();

        Label type = new Label(e.getType().toUpperCase());
        type.setStyle(MONO + "-fx-font-size:11px;-fx-font-weight:bold;-fx-text-fill:" + PURPLE + ";");

        Label title = new Label(e.getTitle());
        title.setWrapText(true);
        title.setStyle("-fx-font-size:18px;-fx-font-weight:bold;-fx-text-fill:#1f1a24;");

        VBox info = new VBox(6, type);
        if (!e.getSubject().isBlank()) {
            Label subject = new Label(e.getSubject());
            subject.setWrapText(true);
            subject.setStyle("-fx-font-size:13px;-fx-text-fill:#6b6270;");
            info.getChildren().add(subject);
        }
        info.getChildren().addAll(title, pill(r), chipRow(r));
        Label faculty = new Label(e.getFaculty().isBlank() ? "Administrator" : e.getFaculty());
        faculty.setStyle("-fx-font-size:13px;-fx-text-fill:#6b6270;");
        info.getChildren().add(faculty);
        HBox.setHgrow(info, Priority.ALWAYS);

        VBox actionBox = new VBox(actionButton(r));
        actionBox.setAlignment(Pos.TOP_RIGHT);

        HBox card = new HBox(14, icon(e, a == ExamAccess.OPEN), info, actionBox);
        card.setAlignment(Pos.TOP_LEFT);
        card.setPadding(new Insets(16));
        card.setStyle(cardStyle());
        return card;
    }

    private Node pill(Row r) {
        String bg = LAVENDER, fg = PURPLE, text;
        switch (r.access()) {
            case OPEN -> {
                bg = "#fdf0d5";
                fg = "#9a6a12";
                text = r.exam().windowText(now);
            }
            case UPCOMING -> text = r.exam().windowText(now);
            case ATTEMPTED -> text = "Results out   |   " + r.result().getMarksText() + "   |   "
                    + String.format("%.2f%%", r.result().getPercentage()) + "   |   " + r.result().getStatus();
            case CLOSED -> {
                bg = "#fde4e1";
                fg = "#b42318";
                text = "Not attempted   |   " + r.exam().windowText(now);
            }
            default -> {
                bg = "#fde4e1";
                fg = "#b42318";
                text = "Attempt interrupted - please contact your faculty";
            }
        }
        Label l = new Label(text);
        l.setWrapText(true);
        l.setMaxWidth(Double.MAX_VALUE);
        l.setStyle(MONO + "-fx-font-size:12px;-fx-padding:9 14 9 14;-fx-background-radius:10;"
                + "-fx-background-color:" + bg + ";-fx-text-fill:" + fg + ";");
        return l;
    }

    private Node chipRow(Row r) {
        Exam e = r.exam();
        HBox row = new HBox(8,
                smallChip(e.getDurationMinutes() + " min"),
                smallChip(r.questions() + " questions"),
                smallChip("Marks: +" + ExamResult.fmt(e.getMarksPerQuestion())
                        + (e.getNegativeMarks() > 0 ? " / -" + ExamResult.fmt(e.getNegativeMarks()) : "")));
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    private Label smallChip(String text) {
        Label l = new Label(text);
        l.setStyle(MONO + "-fx-font-size:12px;-fx-text-fill:#4a4350;-fx-background-color:#f3eef6;"
                + "-fx-background-radius:8;-fx-padding:5 10 5 10;");
        return l;
    }

    private Button actionButton(Row r) {
        String label;
        boolean enabled = true;
        switch (r.access()) {
            case OPEN -> label = "Start";
            case ATTEMPTED -> label = "Review";
            case UPCOMING -> {
                label = "Not open";
                enabled = false;
            }
            case CLOSED -> {
                label = "Closed";
                enabled = false;
            }
            default -> {
                label = "Locked";
                enabled = false;
            }
        }
        Button b = new Button(label);
        b.setMinWidth(100);
        b.setStyle("-fx-background-color:" + (enabled ? PURPLE : "#d9d1de") + ";"
                + "-fx-text-fill:" + (enabled ? "white" : "#6b6270") + ";-fx-font-size:14px;"
                + "-fx-font-weight:bold;-fx-background-radius:12;-fx-padding:9 22 9 22;"
                + (enabled ? "-fx-cursor:hand;" : ""));
        b.setDisable(!enabled);
        if (r.access() == ExamAccess.OPEN) b.setOnAction(ev -> onStart.accept(r.exam()));
        if (r.access() == ExamAccess.ATTEMPTED) b.setOnAction(ev -> onReview.accept(r.result()));
        return b;
    }

    private StackPane icon(Exam e, boolean highlight) {
        Group g = new Group();
        if (e.getType().toLowerCase().contains("objective")) {          // target for objective tests
            g.getChildren().addAll(ring(12), ring(7));
            Circle dot = new Circle(2.5, Color.web(PURPLE));
            g.getChildren().add(dot);
        } else {                                                        // document for everything else
            SVGPath doc = new SVGPath();
            doc.setContent("M-8 -11 L3 -11 L9 -5 L9 11 L-8 11 Z M3 -11 L3 -5 L9 -5 M-4 1 L5 1 M-4 6 L5 6");
            doc.setFill(Color.TRANSPARENT);
            doc.setStroke(Color.web(PURPLE));
            doc.setStrokeWidth(1.8);
            g.getChildren().add(doc);
        }
        StackPane box = new StackPane(g);
        box.setMinSize(52, 52);
        box.setMaxSize(52, 52);
        box.setStyle("-fx-background-color:" + LAVENDER + ";-fx-background-radius:14;"
                + (highlight ? "-fx-border-color:#c98a1a;-fx-border-width:2;-fx-border-radius:14;" : ""));
        return box;
    }

    private Circle ring(double radius) {
        Circle c = new Circle(radius);
        c.setFill(Color.TRANSPARENT);
        c.setStroke(Color.web(PURPLE));
        c.setStrokeWidth(1.8);
        return c;
    }

    private String cardStyle() {
        return "-fx-background-color:white;-fx-background-radius:18;-fx-border-color:#e6e0ea;"
                + "-fx-border-radius:18;-fx-border-width:1.5;";
    }
}
