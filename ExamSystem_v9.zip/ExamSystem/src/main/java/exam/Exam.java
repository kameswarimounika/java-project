package exam;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Locale;

/**
 * One exam that the administrator publishes: title, subject, faculty, its own timer and marking rules,
 * and an optional window (opens at / closes at) during which students may start it.
 */
public class Exam {
    public static final String DEFAULT_ID = "E1";          // the exam that old (v8) data belongs to
    public static final String DEFAULT_TITLE = "General Exam";
    public static final String[] TYPES = {"Objective Test", "Quiz", "Assessment", "Mid-Term", "Final Exam"};

    /** Format the administrator types and the file stores: 2026-11-13 22:30 */
    public static final DateTimeFormatter INPUT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private static final DateTimeFormatter SHOW = DateTimeFormatter.ofPattern("MMM d, h:mm a", Locale.ENGLISH);

    private final String id;
    private final String title;
    private final String subject;
    private final String type;
    private final String faculty;
    private final int durationMinutes;
    private final int marksPerQuestion;
    private final double negativeMarks;
    private final int questionsPerExam;      // 0 = use every question
    private final LocalDateTime start;       // null = already open
    private final LocalDateTime end;         // null = never closes

    public Exam(String id, String title, String subject, String type, String faculty,
                int durationMinutes, int marksPerQuestion, double negativeMarks, int questionsPerExam,
                LocalDateTime start, LocalDateTime end) {
        this.id = id;
        this.title = title;
        this.subject = subject;
        this.type = type;
        this.faculty = faculty;
        this.durationMinutes = durationMinutes;
        this.marksPerQuestion = marksPerQuestion;
        this.negativeMarks = negativeMarks;
        this.questionsPerExam = questionsPerExam;
        this.start = start;
        this.end = end;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getSubject() { return subject; }
    public String getType() { return type; }
    public String getFaculty() { return faculty; }
    public int getDurationMinutes() { return durationMinutes; }
    public int getMarksPerQuestion() { return marksPerQuestion; }
    public double getNegativeMarks() { return negativeMarks; }
    public int getQuestionsPerExam() { return questionsPerExam; }
    public LocalDateTime getStart() { return start; }
    public LocalDateTime getEnd() { return end; }

    public Exam withId(String newId) {
        return new Exam(newId, title, subject, type, faculty, durationMinutes, marksPerQuestion,
                negativeMarks, questionsPerExam, start, end);
    }

    /** One line such as "Started Nov 5, 11:00 AM  |  Ends Nov 13, 10:30 PM". */
    public String windowText(LocalDateTime now) {
        if (start == null && end == null) return "Open anytime";
        StringBuilder sb = new StringBuilder();
        if (start != null) sb.append(now.isBefore(start) ? "Starts " : "Started ").append(start.format(SHOW));
        if (end != null) {
            if (sb.length() > 0) sb.append("   |   ");
            sb.append(now.isAfter(end) ? "Closed " : "Ends ").append(end.format(SHOW));
        }
        return sb.toString();
    }

    public static LocalDateTime parseTime(String s) {
        if (s == null || s.isBlank()) return null;
        try {
            return LocalDateTime.parse(s.trim().replace('T', ' '), INPUT);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    public static String formatTime(LocalDateTime t) {
        return t == null ? "" : t.format(INPUT);
    }

    // ------------------------------------------------------------------
    // File format: one tab-separated line per exam
    // ------------------------------------------------------------------
    public String toLine() {
        return String.join("\t", id, clean(title), clean(subject), clean(type), clean(faculty),
                String.valueOf(durationMinutes), String.valueOf(marksPerQuestion),
                Double.toString(negativeMarks), String.valueOf(questionsPerExam),
                formatTime(start), formatTime(end));
    }

    /** Returns null for malformed lines. */
    public static Exam fromLine(String line) {
        String[] p = line.split("\t", -1);
        if (p.length != 11) return null;
        try {
            return new Exam(p[0], p[1], p[2], p[3], p[4],
                    Math.max(1, Integer.parseInt(p[5].trim())),
                    Math.max(1, Integer.parseInt(p[6].trim())),
                    Math.max(0, Double.parseDouble(p[7].trim())),
                    Math.max(0, Integer.parseInt(p[8].trim())),
                    parseTime(p[9]), parseTime(p[10]));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace("\t", " ").replace("\r", " ").replace("\n", " ").trim();
    }

    @Override
    public String toString() {
        return title;
    }
}
