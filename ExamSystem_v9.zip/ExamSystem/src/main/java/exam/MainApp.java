package exam;

import javafx.animation.Animation;
import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.util.StringConverter;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public class MainApp extends Application {

    private static final double W = 980, H = 700;

    private Stage stage;
    private Scene scene;

    private final QuestionBank bank = new QuestionBank();
    private final HistoryStore history = new HistoryStore();
    private final UserStore users = new UserStore();
    private final ExamStore exams = new ExamStore(new ExamSettings());   // old settings.txt is only used once, to migrate

    private User currentUser;
    private Exam currentExam;       // the exam being written right now

    // ---- exam state ----
    private List<Question> paper;
    private int[][] order;          // order[q][position shown] = original option index
    private int[] answers;          // answers[q] = position the student chose (-1 = none)
    private int current;
    private int totalSeconds;
    private boolean submitted;
    private boolean examActive;
    private double examMarks;       // settings captured when the exam starts
    private double examNegative;
    private ExamTimer timer;
    private Animation pulse;

    // ---- last result (for the review screen) ----
    private ExamResult lastResult;
    private int lastUnanswered;
    private boolean lastAuto;

    // ---- exam widgets ----
    private Label timerLabel, qNumLabel, qTextLabel;
    private ProgressBar timeBar;
    private RadioButton[] radios;
    private ToggleGroup group;
    private Button prevBtn, nextBtn;
    private FlowPane navPane;
    private VBox questionBox;

    @Override
    public void start(Stage primaryStage) {
        stage = primaryStage;
        stage.setTitle("Smart Online Examination System");
        scene = new Scene(new StackPane(), W, H);
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(640);

        // closing the window in the middle of an exam submits it (no escaping a bad attempt)
        stage.setOnCloseRequest(ev -> {
            if (examActive) {
                Alert a = new Alert(Alert.AlertType.CONFIRMATION,
                        "An exam is in progress. Closing now will submit it. Close anyway?",
                        ButtonType.YES, ButtonType.NO);
                a.setHeaderText(null);
                if (a.showAndWait().orElse(ButtonType.NO) == ButtonType.YES) finishExam(true);
                else ev.consume();
            }
        });

        if (users.hasAdmin()) showLogin();
        else showAdminSetup();
        stage.show();
    }

    @Override
    public void stop() {
        if (timer != null) timer.stop();
    }

    /** Puts a screen on top of the background. */
    private void show(Region content) {
        StackPane.setMargin(content, new Insets(24));
        scene.setRoot(Theme.background(content));
        Theme.fadeIn(content);
    }

    private void info(String msg) {
        Alert a = new Alert(Alert.AlertType.INFORMATION, msg, ButtonType.OK);
        a.setHeaderText(null);
        a.showAndWait();
    }

    private void warn(String msg) {
        Alert a = new Alert(Alert.AlertType.WARNING, msg, ButtonType.OK);
        a.setHeaderText(null);
        a.showAndWait();
    }

    private void wide(Button... buttons) {
        for (Button b : buttons) b.setMaxWidth(Double.MAX_VALUE);
    }

    private boolean isAdminUser() {
        return currentUser != null && currentUser.isAdmin();
    }

    private void goHome() {
        if (currentUser == null) showLogin();
        else if (currentUser.isAdmin()) showAdminMenu();
        else showStudentMenu();
    }

    /** Number of questions one exam will contain, after the exam's own limit is applied. */
    private int examQuestionCount(Exam e) {
        int total = bank.countFor(e.getId());
        int n = e.getQuestionsPerExam();
        return (n > 0 && n < total) ? n : total;
    }

    private String markingRule(Exam e) {
        String neg = e.getNegativeMarks() > 0
                ? ", -" + ExamResult.fmt(e.getNegativeMarks()) + " per wrong answer"
                : ", no negative marking";
        return "+" + ExamResult.fmt(e.getMarksPerQuestion()) + " per correct answer" + neg;
    }

    /** Fresh check, straight from the files, of whether the current student may start this exam. */
    private ExamAccess accessFor(Exam e) {
        String u = currentUser.getUsername();
        return ExamAccess.of(e, history.findFor(u, e.getId()) != null, history.hasStarted(u, e.getId()),
                bank.countFor(e.getId()), LocalDateTime.now());
    }

    // =====================================================================
    // LOGIN / REGISTER / PASSWORDS
    // =====================================================================
    private void showLogin() {
        currentUser = null;

        Label title = Theme.title("Smart Online Examination");
        Label sub = Theme.subtitle("Sign in to continue");

        ToggleGroup roleGroup = new ToggleGroup();
        RadioButton studentRb = new RadioButton("Student");
        RadioButton adminRb = new RadioButton("Administrator");
        studentRb.setToggleGroup(roleGroup);
        adminRb.setToggleGroup(roleGroup);
        studentRb.setSelected(true);
        HBox roleRow = new HBox(24, studentRb, adminRb);
        roleRow.setAlignment(Pos.CENTER);

        TextField userField = Theme.field("Username");
        PasswordField passField = Theme.passwordField("Password");
        Button login = Theme.primary("Login");
        Button forgot = Theme.link("Forgot password?");
        Button register = Theme.link("New student? Register here");
        wide(login);

        Runnable doLogin = () -> {
            String name = userField.getText().trim();
            long wait = users.lockSecondsLeft(name);
            if (wait > 0) {
                warn("Too many failed attempts. Try again in " + wait + " seconds.");
                return;
            }
            User u = users.authenticate(name, passField.getText());
            // same message for a wrong password, unknown user or wrong role: reveals nothing
            if (u == null || adminRb.isSelected() != u.isAdmin()) {
                users.recordFailure(name);
                warn("Invalid username or password.");
                passField.clear();
                return;
            }
            users.clearFailures(name);
            currentUser = u;
            goHome();
        };
        login.setOnAction(e -> doLogin.run());
        passField.setOnAction(e -> doLogin.run());
        forgot.setOnAction(e -> showForgotPassword());
        register.setOnAction(e -> showRegister());

        show(Theme.card(430, title, sub, roleRow, userField, passField, login, forgot, register));
    }

    /** Shown only when no administrator exists, so there is never a default password. */
    private void showAdminSetup() {
        Label title = Theme.title("First-Time Setup");
        Label sub = Theme.subtitle("Create the administrator account. Remember these details.");
        TextField fullName = Theme.field("Full name");
        TextField username = Theme.field("Administrator username");
        PasswordField p1 = Theme.passwordField("Password (6+ characters, letters and digits)");
        PasswordField p2 = Theme.passwordField("Confirm password");
        ComboBox<String> question = new ComboBox<>(FXCollections.observableArrayList(UserStore.QUESTIONS));
        question.setPromptText("Security question (for password reset)");
        question.setMaxWidth(Double.MAX_VALUE);
        TextField answer = Theme.field("Answer to the security question");
        Button create = Theme.success("Create Administrator");
        wide(create);

        create.setOnAction(e -> {
            if (!p1.getText().equals(p2.getText())) {
                warn("Passwords do not match.");
                return;
            }
            String err = users.registerAdmin(fullName.getText(), username.getText(), p1.getText(),
                    question.getValue(), answer.getText());
            if (err != null) {
                warn(err);
                return;
            }
            info("Administrator account created. Please log in.");
            showLogin();
        });

        show(Theme.card(460, title, sub, fullName, username, p1, p2, question, answer, create));
    }

    private void showRegister() {
        Label title = Theme.title("Student Registration");
        TextField fullName = Theme.field("Full name");
        TextField username = Theme.field("Choose a username");
        PasswordField p1 = Theme.passwordField("Password (6+ characters, letters and digits)");
        PasswordField p2 = Theme.passwordField("Confirm password");
        ComboBox<String> question = new ComboBox<>(FXCollections.observableArrayList(UserStore.QUESTIONS));
        question.setPromptText("Security question (for password reset)");
        question.setMaxWidth(Double.MAX_VALUE);
        TextField answer = Theme.field("Answer to the security question");
        Button create = Theme.success("Create Account");
        Button back = Theme.secondary("Back to Login");
        wide(create, back);

        create.setOnAction(e -> {
            if (!p1.getText().equals(p2.getText())) {
                warn("Passwords do not match.");
                return;
            }
            String err = users.registerStudent(fullName.getText(), username.getText(), p1.getText(),
                    question.getValue(), answer.getText());
            if (err != null) {
                warn(err);
                return;
            }
            info("Account created. You can log in now.");
            showLogin();
        });
        back.setOnAction(e -> showLogin());

        show(Theme.card(460, title, fullName, username, p1, p2, question, answer, create, back));
    }

    private void showForgotPassword() {
        Label title = Theme.title("Reset Password");
        Label sub = Theme.subtitle("Enter your username to see your security question.");
        TextField username = Theme.field("Username");
        Button next = Theme.primary("Continue");
        Button back = Theme.secondary("Back to Login");
        wide(next, back);

        next.setOnAction(e -> {
            String name = username.getText().trim();
            String q = users.getSecurityQuestion(name);
            if (q == null) {
                warn("No account found with that username.");
                return;
            }
            showResetForm(name, q);
        });
        back.setOnAction(e -> showLogin());

        show(Theme.card(430, title, sub, username, next, back));
    }

    private void showResetForm(String username, String question) {
        Label title = Theme.title("Reset Password");
        Label q = new Label(question);
        q.setWrapText(true);
        q.setStyle(Theme.FONT + "-fx-font-size:15px;-fx-font-weight:bold;-fx-text-fill:#1f2937;");
        TextField answer = Theme.field("Your answer");
        PasswordField p1 = Theme.passwordField("New password (6+ characters, letters and digits)");
        PasswordField p2 = Theme.passwordField("Confirm new password");
        Button reset = Theme.success("Reset Password");
        Button back = Theme.secondary("Cancel");
        wide(reset, back);

        reset.setOnAction(e -> {
            if (!p1.getText().equals(p2.getText())) {
                warn("Passwords do not match.");
                return;
            }
            String err = users.resetPassword(username, answer.getText(), p1.getText());
            if (err != null) {
                warn(err);
                return;
            }
            info("Password changed. You can log in now.");
            showLogin();
        });
        back.setOnAction(e -> showLogin());

        show(Theme.card(430, title, q, answer, p1, p2, reset, back));
    }

    private void showChangePassword() {
        if (currentUser == null) { showLogin(); return; }
        Label title = Theme.title("Change Password");
        PasswordField oldPw = Theme.passwordField("Current password");
        PasswordField p1 = Theme.passwordField("New password (6+ characters, letters and digits)");
        PasswordField p2 = Theme.passwordField("Confirm new password");
        Button save = Theme.success("Save");
        Button back = Theme.secondary("Back");
        wide(save, back);

        save.setOnAction(e -> {
            if (!p1.getText().equals(p2.getText())) {
                warn("New passwords do not match.");
                return;
            }
            String err = users.changePassword(currentUser.getUsername(), oldPw.getText(), p1.getText());
            if (err != null) {
                warn(err);
                return;
            }
            info("Password changed.");
            goHome();
        });
        back.setOnAction(e -> goHome());

        show(Theme.card(430, title, oldPw, p1, p2, save, back));
    }

    // =====================================================================
    // STUDENT MENU
    // =====================================================================
    private void showStudentMenu() {
        if (currentUser == null || currentUser.isAdmin()) { showLogin(); return; }
        String username = currentUser.getUsername();
        List<ExamResult> mine = history.loadForUser(username);
        Set<String> started = history.startedExamIds(username);

        StudentDashboard dash = new StudentDashboard(currentUser, exams.all(), bank, mine, started,
                this::confirmStart, this::showPastResult,
                () -> showHistory(false), this::showChangePassword, this::showLogin);
        Region view = dash.build();
        Theme.stopAnimations();             // the dashboard is a plain full-window screen
        scene.setRoot(view);
        Theme.fadeIn(view);
    }

    private void confirmStart(Exam e) {
        Exam fresh = exams.find(e.getId());
        if (fresh == null) {
            warn("This exam is no longer available.");
            showStudentMenu();
            return;
        }
        ExamAccess access = accessFor(fresh);
        if (!access.canStart()) {
            warn(access.message());
            showStudentMenu();
            return;
        }
        String msg = fresh.getTitle() + "\n"
                + (fresh.getSubject().isBlank() ? "" : fresh.getSubject() + "\n")
                + "\nThis exam has " + examQuestionCount(fresh) + " questions and lasts "
                + fresh.getDurationMinutes() + " minutes.\n" + markingRule(fresh)
                + "\n\nYou can write this exam only ONCE. Once you start, it cannot be restarted."
                + "\n\nStart now?";
        Alert a = new Alert(Alert.AlertType.CONFIRMATION, msg, ButtonType.YES, ButtonType.NO);
        a.setHeaderText("Start \"" + fresh.getTitle() + "\"?");
        a.showAndWait().filter(b -> b == ButtonType.YES).ifPresent(b -> startExam(fresh));
    }

    /** "Review" on the dashboard: the result of an exam that was already written. */
    private void showPastResult(ExamResult r) {
        // right after submitting in this session the full answer review is still available
        if (lastResult != null && lastResult.getExamId().equals(r.getExamId())
                && lastResult.getTimestamp().equals(r.getTimestamp())) {
            showResult(lastResult, lastUnanswered, lastAuto);
            return;
        }
        Label title = Theme.title(r.getExamTitle());
        Label when = Theme.subtitle("Written on " + r.getTimestamp());
        String color = switch (r.getStatus()) {
            case "Excellent" -> "#2e7d32";
            case "Good" -> "#1565c0";
            case "Pass" -> "#ef6c00";
            default -> "#c62828";
        };
        Label status = new Label(r.getStatus());
        status.setStyle(Theme.FONT + "-fx-font-size:38px;-fx-font-weight:bold;-fx-text-fill:" + color + ";");
        Label details = new Label("Marks: " + r.getMarksText() + "\n"
                + String.format("Percentage: %.2f%%", r.getPercentage()) + "\n"
                + "Correct answers: " + r.getCorrect() + " of " + r.getTotal());
        details.setStyle(Theme.FONT + "-fx-font-size:15px;-fx-text-fill:#374151;");

        ObservableList<PieChart.Data> slices = FXCollections.observableArrayList();
        if (r.getCorrect() > 0) slices.add(new PieChart.Data("Correct", r.getCorrect()));
        if (r.getTotal() - r.getCorrect() > 0) slices.add(new PieChart.Data("Not correct", r.getTotal() - r.getCorrect()));
        PieChart chart = new PieChart(slices);
        chart.setLabelsVisible(false);
        chart.setPrefSize(280, 230);
        chart.setMinSize(240, 200);
        chart.setMaxHeight(240);

        VBox text = new VBox(8, status, details);
        text.setAlignment(Pos.CENTER_LEFT);
        HBox middle = new HBox(24, chart, text);
        middle.setAlignment(Pos.CENTER);

        Button back = Theme.success("Back to Dashboard");
        back.setOnAction(e -> goHome());
        show(Theme.card(780, title, when, middle, back));
    }

    // =====================================================================
    // EXAM
    // =====================================================================
    private void startExam(Exam exam) {
        if (currentUser == null || currentUser.isAdmin()) { showLogin(); return; }

        // last safety net for "each exam only once": checked again, from the files, right before the start
        ExamAccess access = accessFor(exam);
        if (!access.canStart()) {
            warn(access.message());
            showStudentMenu();
            return;
        }
        // recorded BEFORE the first question appears, so closing/killing the program cannot give a second try
        if (!history.markStarted(currentUser.getUsername(), exam.getId())) {
            warn("Could not record the start of your exam, so it cannot begin. Please try again.");
            return;
        }
        currentExam = exam;

        // random selection of questions, and a random order of the options for each question
        List<Question> all = new ArrayList<>(bank.forExam(exam.getId()));
        Collections.shuffle(all);
        int n = exam.getQuestionsPerExam();
        paper = (n > 0 && n < all.size()) ? new ArrayList<>(all.subList(0, n)) : all;

        order = new int[paper.size()][];
        for (int i = 0; i < paper.size(); i++) {
            List<Integer> idx = new ArrayList<>(Arrays.asList(0, 1, 2, 3));
            Collections.shuffle(idx);
            order[i] = new int[]{idx.get(0), idx.get(1), idx.get(2), idx.get(3)};
        }

        answers = new int[paper.size()];
        Arrays.fill(answers, -1);
        current = 0;
        submitted = false;
        examActive = true;
        pulse = null;
        examMarks = exam.getMarksPerQuestion();
        examNegative = exam.getNegativeMarks();
        totalSeconds = exam.getDurationMinutes() * 60;   // set by the administrator for this exam

        buildExamScene();
        updateTimerLabel(totalSeconds);

        timer = new ExamTimer(totalSeconds, this::updateTimerLabel, () -> finishExam(true));
        timer.start();
    }

    private void buildExamScene() {
        Label who = new Label(currentExam.getTitle() + "   |   " + currentUser.getFullName());
        who.setStyle(Theme.FONT + "-fx-font-size:15px;-fx-font-weight:bold;-fx-text-fill:#374151;");
        timerLabel = new Label();
        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);
        HBox header = new HBox(10, who, spacer, timerLabel);
        header.setAlignment(Pos.CENTER_LEFT);

        timeBar = new ProgressBar(1.0);
        timeBar.setMaxWidth(Double.MAX_VALUE);
        timeBar.setStyle("-fx-accent: #4f46e5;");

        qNumLabel = new Label();
        qNumLabel.setStyle(Theme.FONT + "-fx-font-size:13px;-fx-text-fill:#6b7280;");
        qTextLabel = new Label();
        qTextLabel.setWrapText(true);
        qTextLabel.setStyle(Theme.FONT + "-fx-font-size:20px;-fx-font-weight:bold;-fx-text-fill:#1f2937;");

        group = new ToggleGroup();
        radios = new RadioButton[4];
        VBox opts = new VBox(10);
        for (int i = 0; i < 4; i++) {
            final RadioButton rb = new RadioButton();
            radios[i] = rb;
            rb.setToggleGroup(group);
            rb.setWrapText(true);
            rb.setMaxWidth(Double.MAX_VALUE);
            styleOption(rb, false);
            rb.selectedProperty().addListener((obs, was, now) -> styleOption(rb, now));
            opts.getChildren().add(rb);
        }
        questionBox = new VBox(14, qNumLabel, qTextLabel, opts);

        prevBtn = Theme.secondary("<  Previous");
        nextBtn = Theme.primary("Next  >");
        Button submit = Theme.success("Submit Exam");
        prevBtn.setOnAction(e -> { saveAnswer(); current--; renderQuestion(); });
        nextBtn.setOnAction(e -> { saveAnswer(); current++; renderQuestion(); });
        submit.setOnAction(e -> confirmSubmit());

        Region spacer2 = new Region();
        HBox.setHgrow(spacer2, Priority.ALWAYS);
        HBox nav = new HBox(10, prevBtn, nextBtn, spacer2, submit);

        Label jump = new Label("Jump to question  (blue = current, green = answered, grey = not answered)");
        jump.setStyle(Theme.FONT + "-fx-font-size:12px;-fx-text-fill:#6b7280;");
        navPane = new FlowPane(6, 6);

        VBox card = Theme.card(920, header, timeBar, questionBox, new Separator(), jump, navPane, nav);
        card.setAlignment(Pos.TOP_LEFT);
        show(card);
        renderQuestion();
    }

    private void styleOption(RadioButton rb, boolean selected) {
        rb.setStyle(Theme.FONT + "-fx-font-size:15px;-fx-padding:11 14 11 14;-fx-background-radius:10;"
                + "-fx-text-fill:#1f2937;"
                + (selected
                ? "-fx-background-color:#e0e7ff;-fx-border-color:#6366f1;-fx-border-radius:10;"
                : "-fx-background-color:#f3f4f6;-fx-border-color:transparent;-fx-border-radius:10;"));
    }

    private void renderQuestion() {
        Question q = paper.get(current);
        qNumLabel.setText("Question " + (current + 1) + " of " + paper.size());
        qTextLabel.setText(q.getText());
        group.selectToggle(null);
        for (int i = 0; i < 4; i++) radios[i].setText(q.getOptions()[order[current][i]]);
        if (answers[current] >= 0) group.selectToggle(radios[answers[current]]);
        prevBtn.setDisable(current == 0);
        nextBtn.setDisable(current == paper.size() - 1);
        refreshNavigator();
        Theme.fadeIn(questionBox);
    }

    private void refreshNavigator() {
        navPane.getChildren().clear();
        for (int i = 0; i < paper.size(); i++) {
            final int idx = i;
            Button b = new Button(String.valueOf(i + 1));
            b.setMinSize(36, 36);
            String color = (i == current) ? "#4f46e5" : (answers[i] >= 0 ? "#2e7d32" : "#9e9e9e");
            b.setStyle("-fx-background-color:" + color + ";-fx-text-fill:white;-fx-font-weight:bold;"
                    + "-fx-background-radius:18;-fx-cursor:hand;");
            b.setOnAction(e -> { saveAnswer(); current = idx; renderQuestion(); });
            navPane.getChildren().add(b);
        }
    }

    private void saveAnswer() {
        Toggle t = group.getSelectedToggle();
        answers[current] = (t == null) ? -1 : group.getToggles().indexOf(t);
    }

    private void updateTimerLabel(int secs) {
        if (submitted) return;
        timerLabel.setText(String.format("Time left  %02d:%02d", secs / 60, secs % 60));
        timeBar.setProgress(totalSeconds == 0 ? 0 : (double) secs / totalSeconds);
        boolean low = secs <= 60;
        timerLabel.setStyle(Theme.FONT + "-fx-font-size:20px;-fx-font-weight:bold;-fx-text-fill:"
                + (low ? "#c62828" : "#1a237e") + ";");
        if (low && secs > 0 && pulse == null) {          // pulsing effect in the last minute
            FadeTransition ft = new FadeTransition(Duration.millis(600), timerLabel);
            ft.setFromValue(1.0);
            ft.setToValue(0.35);
            ft.setAutoReverse(true);
            ft.setCycleCount(Animation.INDEFINITE);
            ft.play();
            pulse = ft;
        }
    }

    private void confirmSubmit() {
        saveAnswer();
        long unanswered = Arrays.stream(answers).filter(x -> x < 0).count();
        String msg = unanswered > 0
                ? "You have " + unanswered + " unanswered question(s). Submit anyway?"
                : "Submit your exam now?";
        Alert a = new Alert(Alert.AlertType.CONFIRMATION, msg, ButtonType.YES, ButtonType.NO);
        a.setHeaderText(null);
        a.showAndWait().filter(b -> b == ButtonType.YES).ifPresent(b -> finishExam(false));
    }

    /** Evaluates the paper. Called on manual submit, when the timer expires, and when the window is closed. */
    private void finishExam(boolean autoSubmitted) {
        if (submitted) return;
        saveAnswer();
        submitted = true;
        examActive = false;
        if (timer != null) timer.stop();
        if (pulse != null) {
            pulse.stop();
            pulse = null;
        }

        int correct = 0, wrong = 0, unanswered = 0;
        for (int i = 0; i < paper.size(); i++) {
            if (answers[i] < 0) unanswered++;
            else if (order[i][answers[i]] == paper.get(i).getCorrectIndex()) correct++;
            else wrong++;
        }
        double score = Math.max(0, correct * examMarks - wrong * examNegative);
        double max = paper.size() * examMarks;

        ExamResult result = ExamResult.now(currentUser.getUsername(), currentUser.getFullName(),
                currentExam.getId(), currentExam.getTitle(), paper.size(), correct, score, max);
        history.add(result);

        lastResult = result;
        lastUnanswered = unanswered;
        lastAuto = autoSubmitted;
        showResult(result, unanswered, autoSubmitted);
    }

    // =====================================================================
    // RESULT AND ANSWER REVIEW
    // =====================================================================
    private void showResult(ExamResult r, int unanswered, boolean auto) {
        Label title = Theme.title(auto ? "Time is up - exam auto-submitted" : "Exam Submitted");

        String color = switch (r.getStatus()) {
            case "Excellent" -> "#2e7d32";
            case "Good" -> "#1565c0";
            case "Pass" -> "#ef6c00";
            default -> "#c62828";
        };
        Label status = new Label(r.getStatus());
        status.setStyle(Theme.FONT + "-fx-font-size:38px;-fx-font-weight:bold;-fx-text-fill:" + color + ";");

        int wrong = r.getTotal() - r.getCorrect() - unanswered;
        StringBuilder sb = new StringBuilder();
        sb.append("Exam: ").append(r.getExamTitle()).append('\n');
        sb.append("Student: ").append(r.getStudentName()).append('\n');
        sb.append("Marks: ").append(r.getMarksText()).append('\n');
        sb.append(String.format("Percentage: %.2f%%", r.getPercentage())).append('\n');
        sb.append("Correct: ").append(r.getCorrect())
                .append("    Wrong: ").append(wrong)
                .append("    Unanswered: ").append(unanswered);
        if (examNegative > 0) {
            sb.append('\n').append("(-").append(ExamResult.fmt(examNegative)).append(" for each wrong answer)");
        }
        Label details = new Label(sb.toString());
        details.setStyle(Theme.FONT + "-fx-font-size:15px;-fx-text-fill:#374151;");

        ObservableList<PieChart.Data> slices = FXCollections.observableArrayList();
        if (r.getCorrect() > 0) slices.add(new PieChart.Data("Correct", r.getCorrect()));
        if (wrong > 0) slices.add(new PieChart.Data("Wrong", wrong));
        if (unanswered > 0) slices.add(new PieChart.Data("Unanswered", unanswered));
        PieChart chart = new PieChart(slices);
        chart.setLegendVisible(true);
        chart.setLabelsVisible(false);
        chart.setPrefSize(280, 230);
        chart.setMinSize(240, 200);
        chart.setMaxHeight(240);

        VBox text = new VBox(8, status, details);
        text.setAlignment(Pos.CENTER_LEFT);
        HBox middle = new HBox(24, chart, text);
        middle.setAlignment(Pos.CENTER);

        Button review = Theme.primary("Review Answers");
        Button home = Theme.success("Back to Menu");
        Button hist = Theme.secondary("My Results");
        review.setOnAction(e -> showReview());
        home.setOnAction(e -> goHome());
        hist.setOnAction(e -> showHistory(false));
        HBox buttons = new HBox(10, review, home, hist);
        buttons.setAlignment(Pos.CENTER);

        show(Theme.card(780, title, middle, buttons));
    }

    /** Every question with the student's answer and the correct answer. */
    private void showReview() {
        if (paper == null || answers == null || lastResult == null) { goHome(); return; }

        VBox list = new VBox(12);
        for (int i = 0; i < paper.size(); i++) {
            Question q = paper.get(i);
            boolean answered = answers[i] >= 0;
            String chosen = answered ? q.getOptions()[order[i][answers[i]]] : null;
            boolean right = answered && order[i][answers[i]] == q.getCorrectIndex();

            Label qt = new Label((i + 1) + ". " + q.getText());
            qt.setWrapText(true);
            qt.setStyle(Theme.FONT + "-fx-font-size:15px;-fx-font-weight:bold;-fx-text-fill:#1f2937;");

            Label yours = new Label("Your answer: " + (answered ? chosen : "Not answered"));
            yours.setWrapText(true);
            String yoursColor = right ? "#2e7d32" : (answered ? "#c62828" : "#6b7280");
            yours.setStyle(Theme.FONT + "-fx-font-size:14px;-fx-text-fill:" + yoursColor + ";");

            VBox item = new VBox(4, qt, yours);
            if (!right) {
                Label correct = new Label("Correct answer: " + q.getCorrectAnswerText());
                correct.setWrapText(true);
                correct.setStyle(Theme.FONT + "-fx-font-size:14px;-fx-text-fill:#2e7d32;");
                item.getChildren().add(correct);
            }
            item.setStyle("-fx-background-color:#f3f4f6;-fx-background-radius:12;-fx-padding:12;");
            list.getChildren().add(item);
        }

        ScrollPane scroll = new ScrollPane(list);
        scroll.setFitToWidth(true);
        VBox.setVgrow(scroll, Priority.ALWAYS);

        Button back = Theme.secondary("Back to Result");
        back.setOnAction(e -> showResult(lastResult, lastUnanswered, lastAuto));

        VBox card = Theme.card(820, Theme.title("Answer Review"), scroll, back);
        card.setMaxHeight(Double.MAX_VALUE);
        show(card);
    }

    // =====================================================================
    // HISTORY (with search and CSV export for the administrator)
    // =====================================================================
    /** all = true shows every student's attempts (administrator); false shows only the current student's. */
    private void showHistory(boolean all) {
        if (currentUser == null || (all && !currentUser.isAdmin())) { showLogin(); return; }
        List<ExamResult> data = all ? history.loadAll() : history.loadForUser(currentUser.getUsername());
        Collections.reverse(data);                      // newest first

        FilteredList<ExamResult> filtered = new FilteredList<>(FXCollections.observableArrayList(data), x -> true);
        TableView<ExamResult> table = new TableView<>(filtered);
        table.getColumns().add(col("Student", r -> r.getStudentName(), 150));
        table.getColumns().add(col("Exam", r -> r.getExamTitle(), 170));
        table.getColumns().add(col("Date & Time", r -> r.getTimestamp(), 150));
        table.getColumns().add(col("Marks", r -> r.getMarksText(), 100));
        table.getColumns().add(col("Percentage", r -> String.format("%.2f%%", r.getPercentage()), 100));
        table.getColumns().add(col("Status", r -> r.getStatus(), 100));
        table.setPlaceholder(new Label("No exams attempted yet."));
        VBox.setVgrow(table, Priority.ALWAYS);

        Button back = Theme.secondary("Back");
        back.setOnAction(e -> goHome());

        VBox card = Theme.card(840, Theme.title(all ? "All Student Results" : "My Results"));
        if (all) {
            TextField search = Theme.field("Search by student, username or exam");
            HBox.setHgrow(search, Priority.ALWAYS);
            search.textProperty().addListener((obs, old, text) -> {
                String t = text == null ? "" : text.trim().toLowerCase();
                filtered.setPredicate(x -> t.isEmpty()
                        || x.getStudentName().toLowerCase().contains(t)
                        || x.getExamTitle().toLowerCase().contains(t)
                        || x.getUsername().toLowerCase().contains(t));
            });
            Button export = Theme.success("Export CSV");
            export.setOnAction(e -> exportCsv(new ArrayList<>(filtered)));
            card.getChildren().add(new HBox(10, search, export));
        }
        card.getChildren().addAll(table, back);
        card.setMaxHeight(Double.MAX_VALUE);
        show(card);
    }

    private <T> TableColumn<T, String> col(String name, java.util.function.Function<T, String> f, double width) {
        TableColumn<T, String> c = new TableColumn<>(name);
        c.setCellValueFactory(cd -> new SimpleStringProperty(f.apply(cd.getValue())));
        c.setPrefWidth(width);
        return c;
    }

    private void exportCsv(List<ExamResult> rows) {
        if (!isAdminUser()) return;
        FileChooser chooser = new FileChooser();
        chooser.setTitle("Save results as CSV");
        chooser.setInitialFileName("exam_results.csv");
        File file = chooser.showSaveDialog(stage);
        if (file == null) return;

        List<String> lines = new ArrayList<>();
        lines.add("Username,Student,Exam,Date,Marks,Max Marks,Percentage,Status,Correct,Questions");
        for (ExamResult r : rows) {
            lines.add(String.join(",", csv(r.getUsername()), csv(r.getStudentName()), csv(r.getExamTitle()), csv(r.getTimestamp()),
                    ExamResult.fmt(r.getScore()), ExamResult.fmt(r.getMaxScore()),
                    String.format("%.2f", r.getPercentage()), csv(r.getStatus()),
                    String.valueOf(r.getCorrect()), String.valueOf(r.getTotal())));
        }
        try {
            Files.write(file.toPath(), lines, StandardCharsets.UTF_8);
            info("Saved " + rows.size() + " result(s) to:\n" + file.getAbsolutePath());
        } catch (IOException ex) {
            warn("Could not save the file: " + ex.getMessage());
        }
    }

    /** Quotes a CSV value and defuses spreadsheet formulas such as =CMD(). */
    private String csv(String s) {
        String v = (s == null) ? "" : s;
        if (!v.isEmpty() && "=+-@".indexOf(v.charAt(0)) >= 0) v = "'" + v;
        return "\"" + v.replace("\"", "\"\"") + "\"";
    }

    // =====================================================================
    // ADMIN MENU, SETTINGS, USERS
    // =====================================================================
    private void showAdminMenu() {
        if (!isAdminUser()) { showLogin(); return; }
        Label title = Theme.title("Administrator Panel");
        Label sub = Theme.subtitle("Logged in as " + currentUser.getFullName());
        Label stats = Theme.subtitle(exams.all().size() + " exams  |  "
                + bank.getQuestions().size() + " questions in total");

        Button set = Theme.primary("Manage Exams");
        Button manage = Theme.primary("Manage Questions");
        Button hist = Theme.primary("All Student Results");
        Button usersBtn = Theme.primary("Manage Users and Admins");
        Button changePw = Theme.secondary("Change Password");
        Button logout = Theme.danger("Logout");
        wide(set, manage, hist, usersBtn, changePw, logout);

        manage.setOnAction(e -> showAdmin(null));
        set.setOnAction(e -> showExams());
        hist.setOnAction(e -> showHistory(true));
        usersBtn.setOnAction(e -> showUsers());
        changePw.setOnAction(e -> showChangePassword());
        logout.setOnAction(e -> showLogin());

        show(Theme.card(480, title, sub, stats, set, manage, hist, usersBtn, changePw, logout));
    }

    private Label formLabel(String text) {
        Label l = new Label(text);
        l.setStyle(Theme.FONT + "-fx-font-size:12px;-fx-text-fill:#6b7280;");
        return l;
    }

    private void showExams() {
        if (!isAdminUser()) { showLogin(); return; }

        ObservableList<Exam> list = FXCollections.observableArrayList(exams.all());
        TableView<Exam> table = new TableView<>(list);
        table.getColumns().add(col("Exam", Exam::getTitle, 150));
        table.getColumns().add(col("Subject", Exam::getSubject, 110));
        table.getColumns().add(col("Questions", x -> String.valueOf(bank.countFor(x.getId())), 70));
        table.getColumns().add(col("Time", x -> x.getDurationMinutes() + " min", 60));
        table.setPlaceholder(new Label("No exams yet. Fill in the form and click Add."));
        HBox.setHgrow(table, Priority.ALWAYS);

        TextField title = Theme.field("Exam title (for example: Packages - I)");
        TextField subject = Theme.field("Subject (for example: Object Oriented Programming through JAVA)");
        ComboBox<String> type = new ComboBox<>(FXCollections.observableArrayList(Exam.TYPES));
        type.setEditable(true);
        type.setValue(Exam.TYPES[0]);
        type.setMaxWidth(Double.MAX_VALUE);
        TextField faculty = Theme.field("Faculty name shown to students");
        faculty.setText(currentUser.getFullName());
        Spinner<Integer> minutes = new Spinner<>(1, 300, 30);
        minutes.setEditable(true);
        minutes.setMaxWidth(Double.MAX_VALUE);
        Spinner<Integer> marks = new Spinner<>(1, 100, 1);
        marks.setEditable(true);
        marks.setMaxWidth(Double.MAX_VALUE);
        ComboBox<String> negative = new ComboBox<>(
                FXCollections.observableArrayList("0", "0.25", "0.33", "0.50", "1"));
        negative.setValue("0");
        negative.setMaxWidth(Double.MAX_VALUE);
        Spinner<Integer> count = new Spinner<>(0, 500, 0);
        count.setEditable(true);
        count.setMaxWidth(Double.MAX_VALUE);
        TextField opens = Theme.field("yyyy-MM-dd HH:mm   (blank = open immediately)");
        TextField closes = Theme.field("yyyy-MM-dd HH:mm   (blank = never closes)");

        table.getSelectionModel().selectedItemProperty().addListener((obs, old, x) -> {
            if (x == null) return;
            title.setText(x.getTitle());
            subject.setText(x.getSubject());
            type.getEditor().setText(x.getType());
            type.setValue(x.getType());
            faculty.setText(x.getFaculty());
            minutes.getValueFactory().setValue(x.getDurationMinutes());
            marks.getValueFactory().setValue(x.getMarksPerQuestion());
            negative.setValue(ExamResult.fmt(x.getNegativeMarks()));
            count.getValueFactory().setValue(x.getQuestionsPerExam());
            opens.setText(Exam.formatTime(x.getStart()));
            closes.setText(Exam.formatTime(x.getEnd()));
        });

        Button add = Theme.success("Add");
        Button update = Theme.primary("Update");
        Button delete = Theme.danger("Delete");
        Button clear = Theme.secondary("Clear");
        Button questionsBtn = Theme.primary("Manage Questions of this Exam");
        Button back = Theme.secondary("Back");
        wide(questionsBtn, back);

        Runnable clearForm = () -> {
            table.getSelectionModel().clearSelection();
            title.clear();
            subject.clear();
            type.setValue(Exam.TYPES[0]);
            faculty.setText(currentUser.getFullName());
            minutes.getValueFactory().setValue(30);
            marks.getValueFactory().setValue(1);
            negative.setValue("0");
            count.getValueFactory().setValue(0);
            opens.clear();
            closes.clear();
        };

        add.setOnAction(e -> {
            Exam x = readExamForm("", title, subject, type, faculty, minutes, marks, negative, count, opens, closes);
            if (x == null) return;
            exams.add(x);
            list.setAll(exams.all());
            clearForm.run();
            info("Exam added. Use \"Manage Questions of this Exam\" to add its questions;\n"
                    + "students will see it on their dashboard once it has questions.");
        });
        update.setOnAction(e -> {
            Exam sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { info("Select an exam in the table first."); return; }
            Exam x = readExamForm(sel.getId(), title, subject, type, faculty, minutes, marks, negative, count,
                    opens, closes);
            if (x == null) return;
            exams.update(x);
            list.setAll(exams.all());
        });
        delete.setOnAction(e -> {
            Exam sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { info("Select an exam in the table first."); return; }
            Alert a = new Alert(Alert.AlertType.CONFIRMATION,
                    "Delete the exam '" + sel.getTitle() + "' and its " + bank.countFor(sel.getId())
                            + " question(s)? Students' past results stay in the history.",
                    ButtonType.YES, ButtonType.NO);
            a.setHeaderText(null);
            a.showAndWait().filter(b -> b == ButtonType.YES).ifPresent(b -> {
                bank.removeForExam(sel.getId());
                exams.remove(sel.getId());
                list.setAll(exams.all());
                clearForm.run();
            });
        });
        clear.setOnAction(e -> clearForm.run());
        questionsBtn.setOnAction(e -> {
            Exam sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { info("Select an exam in the table first."); return; }
            showAdmin(sel);
        });
        back.setOnAction(e -> showAdminMenu());

        HBox row1 = new HBox(8, add, update);
        HBox row2 = new HBox(8, delete, clear);
        VBox form = new VBox(6,
                formLabel("Title"), title,
                formLabel("Subject"), subject,
                formLabel("Type (pick one or type your own)"), type,
                formLabel("Faculty"), faculty,
                formLabel("Exam time (minutes)"), minutes,
                formLabel("Marks for each correct answer"), marks,
                formLabel("Marks deducted for each wrong answer"), negative,
                formLabel("Questions per exam (0 = use all questions)"), count,
                formLabel("Opens at"), opens,
                formLabel("Closes at"), closes,
                row1, row2, questionsBtn, back);
        form.setPadding(new Insets(0, 12, 0, 0));
        ScrollPane formScroll = new ScrollPane(form);
        formScroll.setFitToWidth(true);
        formScroll.setPrefWidth(370);
        formScroll.setMinWidth(370);
        formScroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        formScroll.setStyle("-fx-background:transparent;-fx-background-color:transparent;");

        HBox body = new HBox(18, table, formScroll);
        VBox.setVgrow(body, Priority.ALWAYS);

        Label note = Theme.subtitle("Each exam has its own questions, timer and marking. Students can write each exam only once.");
        VBox card = Theme.card(Double.MAX_VALUE, Theme.title("Manage Exams"), note, body);
        card.setMaxHeight(Double.MAX_VALUE);
        show(card);
    }

    /** Reads and checks the exam form. Returns null (after showing a message) if something is wrong. */
    private Exam readExamForm(String id, TextField title, TextField subject, ComboBox<String> type,
                              TextField faculty, Spinner<Integer> minutes, Spinner<Integer> marks,
                              ComboBox<String> negative, Spinner<Integer> count,
                              TextField opens, TextField closes) {
        String t = title.getText().trim();
        if (t.isEmpty()) { warn("The exam title is required."); return null; }
        String kind = type.getEditor().getText() == null ? "" : type.getEditor().getText().trim();
        if (kind.isEmpty() && type.getValue() != null) kind = type.getValue().trim();
        if (kind.isEmpty()) kind = Exam.TYPES[0];
        try {
            int m = Integer.parseInt(minutes.getEditor().getText().trim());
            int mk = Integer.parseInt(marks.getEditor().getText().trim());
            int qn = Integer.parseInt(count.getEditor().getText().trim());
            double ng = Double.parseDouble(negative.getValue());
            if (m < 1 || m > 300) { warn("Exam time must be between 1 and 300 minutes."); return null; }
            if (mk < 1 || mk > 100) { warn("Marks per question must be between 1 and 100."); return null; }
            if (ng < 0 || ng > mk) { warn("Negative marks cannot be more than the marks per question."); return null; }
            if (qn < 0 || qn > 500) { warn("Questions per exam must be between 0 and 500."); return null; }

            LocalDateTime start = Exam.parseTime(opens.getText());
            LocalDateTime end = Exam.parseTime(closes.getText());
            if (!opens.getText().isBlank() && start == null) {
                warn("'Opens at' must look like 2026-11-13 09:30 (year-month-day hour:minute).");
                return null;
            }
            if (!closes.getText().isBlank() && end == null) {
                warn("'Closes at' must look like 2026-11-13 22:30 (year-month-day hour:minute).");
                return null;
            }
            if (start != null && end != null && !end.isAfter(start)) {
                warn("'Closes at' must be later than 'Opens at'.");
                return null;
            }
            return new Exam(id, t, subject.getText().trim(), kind, faculty.getText().trim(),
                    m, mk, ng, qn, start, end);
        } catch (NumberFormatException ex) {
            warn("Please enter valid numbers.");
            return null;
        }
    }

    private void showUsers() {
        if (!isAdminUser()) { showLogin(); return; }
        ObservableList<User> list = FXCollections.observableArrayList(users.all());
        TableView<User> table = new TableView<>(list);
        table.getColumns().add(col("Username", u -> u.getUsername(), 170));
        table.getColumns().add(col("Full name", u -> u.getFullName(), 240));
        table.getColumns().add(col("Role", u -> u.isAdmin() ? "Administrator" : "Student", 130));
        VBox.setVgrow(table, Priority.ALWAYS);

        Button addAdmin = Theme.primary("Add Administrator");
        Button reset = Theme.secondary("Reset Password");
        Button delete = Theme.danger("Delete Account");
        Button back = Theme.secondary("Back");

        addAdmin.setOnAction(e -> showAddAdmin());
        reset.setOnAction(e -> {
            User sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { info("Select an account in the table first."); return; }
            String pw = askNewPassword(sel.getUsername());
            if (pw == null) return;
            String err = users.adminResetPassword(sel.getUsername(), pw);
            if (err != null) warn(err);
            else info("Password reset. Tell " + sel.getFullName() + " the new password.");
        });
        delete.setOnAction(e -> {
            User sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { info("Select an account in the table first."); return; }
            Alert a = new Alert(Alert.AlertType.CONFIRMATION,
                    "Delete the account '" + sel.getUsername() + "'? Their past results stay in the history.",
                    ButtonType.YES, ButtonType.NO);
            a.setHeaderText(null);
            a.showAndWait().filter(b -> b == ButtonType.YES).ifPresent(b -> {
                String err = users.deleteUser(sel.getUsername(), currentUser.getUsername());
                if (err != null) warn(err);
                else list.setAll(users.all());
            });
        });
        back.setOnAction(e -> showAdminMenu());

        HBox buttons = new HBox(10, addAdmin, reset, delete, back);
        VBox card = Theme.card(820, Theme.title("Users and Administrators"), table, buttons);
        card.setMaxHeight(Double.MAX_VALUE);
        show(card);
    }

    /** Asks the administrator for a temporary password. Returns null if cancelled. */
    private String askNewPassword(String username) {
        Dialog<ButtonType> d = new Dialog<>();
        d.setTitle("Reset Password");
        d.setHeaderText("Set a new password for " + username);
        PasswordField pf = new PasswordField();
        pf.setPromptText("New password (6+ characters, letters and digits)");
        d.getDialogPane().setContent(pf);
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        ButtonType result = d.showAndWait().orElse(ButtonType.CANCEL);
        return result == ButtonType.OK ? pf.getText() : null;
    }

    private void showAddAdmin() {
        if (!isAdminUser()) { showLogin(); return; }
        Label title = Theme.title("Add Administrator");
        TextField fullName = Theme.field("Full name");
        TextField username = Theme.field("Administrator username");
        PasswordField p1 = Theme.passwordField("Password (6+ characters, letters and digits)");
        PasswordField p2 = Theme.passwordField("Confirm password");
        ComboBox<String> question = new ComboBox<>(FXCollections.observableArrayList(UserStore.QUESTIONS));
        question.setPromptText("Security question (for password reset)");
        question.setMaxWidth(Double.MAX_VALUE);
        TextField answer = Theme.field("Answer to the security question");
        Button create = Theme.success("Create Administrator");
        Button back = Theme.secondary("Back");
        wide(create, back);

        create.setOnAction(e -> {
            if (!p1.getText().equals(p2.getText())) {
                warn("Passwords do not match.");
                return;
            }
            String err = users.addAdmin(fullName.getText(), username.getText(), p1.getText(),
                    question.getValue(), answer.getText());
            if (err != null) {
                warn(err);
                return;
            }
            info("New administrator created.");
            showUsers();
        });
        back.setOnAction(e -> showUsers());

        show(Theme.card(460, title, fullName, username, p1, p2, question, answer, create, back));
    }

    // =====================================================================
    // ADMIN: MANAGE QUESTIONS
    // =====================================================================
    private void showAdmin(Exam preselect) {
        if (!isAdminUser()) { showLogin(); return; }
        if (exams.all().isEmpty()) {
            info("Create an exam first, then add its questions.");
            showExams();
            return;
        }

        // which exam are the questions for?
        ComboBox<Exam> examBox = new ComboBox<>(FXCollections.observableArrayList(exams.all()));
        examBox.setConverter(new StringConverter<Exam>() {
            @Override
            public String toString(Exam x) { return x == null ? "" : x.getTitle(); }

            @Override
            public Exam fromString(String s) { return null; }
        });
        examBox.setMaxWidth(Double.MAX_VALUE);
        int pick = 0;
        for (int i = 0; i < examBox.getItems().size(); i++) {
            if (preselect != null && examBox.getItems().get(i).getId().equals(preselect.getId())) pick = i;
        }
        examBox.getSelectionModel().select(pick);

        FilteredList<Question> shown = new FilteredList<>(bank.getQuestions(),
                q -> q.getExamId().equals(examBox.getValue().getId()));
        TableView<Question> table = new TableView<>(shown);
        table.getColumns().add(col("Question", Question::getText, 340));
        table.getColumns().add(col("Correct Answer", Question::getCorrectAnswerText, 180));
        table.setPlaceholder(new Label("No questions in this exam yet. Add one using the form."));
        HBox.setHgrow(table, Priority.ALWAYS);

        TextArea qText = new TextArea();
        qText.setPromptText("Question text");
        qText.setPrefRowCount(3);
        qText.setWrapText(true);
        TextField[] optFields = new TextField[4];
        VBox optBox = new VBox(6);
        for (int i = 0; i < 4; i++) {
            optFields[i] = Theme.field("Option " + (char) ('A' + i));
            optBox.getChildren().add(optFields[i]);
        }
        ComboBox<String> correct = new ComboBox<>(FXCollections.observableArrayList("A", "B", "C", "D"));
        correct.getSelectionModel().selectFirst();

        examBox.valueProperty().addListener((obs, old, x) -> {
            if (x == null) return;
            shown.setPredicate(q -> q.getExamId().equals(x.getId()));
            clearForm(table, qText, optFields, correct);
        });

        table.getSelectionModel().selectedItemProperty().addListener((obs, old, q) -> {
            if (q == null) return;
            qText.setText(q.getText());
            for (int i = 0; i < 4; i++) optFields[i].setText(q.getOptions()[i]);
            correct.getSelectionModel().select(q.getCorrectIndex());
        });

        Button add = Theme.success("Add");
        Button update = Theme.primary("Update");
        Button delete = Theme.danger("Delete");
        Button clear = Theme.secondary("Clear");
        Button back = Theme.secondary("Back");
        wide(back);

        add.setOnAction(e -> {
            Question q = readForm(qText, optFields, correct, examBox.getValue().getId());
            if (q != null) {
                bank.add(q);
                clearForm(table, qText, optFields, correct);
            }
        });
        update.setOnAction(e -> {
            Question sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { info("Select a question in the table first."); return; }
            Question q = readForm(qText, optFields, correct, sel.getExamId());
            if (q != null) bank.update(sel, q);
        });
        delete.setOnAction(e -> {
            Question sel = table.getSelectionModel().getSelectedItem();
            if (sel == null) { info("Select a question in the table first."); return; }
            Alert a = new Alert(Alert.AlertType.CONFIRMATION, "Delete this question?", ButtonType.YES, ButtonType.NO);
            a.setHeaderText(null);
            a.showAndWait().filter(b -> b == ButtonType.YES).ifPresent(b -> {
                bank.remove(sel);
                clearForm(table, qText, optFields, correct);
            });
        });
        clear.setOnAction(e -> clearForm(table, qText, optFields, correct));
        back.setOnAction(e -> showAdminMenu());

        Label formTitle = new Label("Question form");
        formTitle.setStyle(Theme.FONT + "-fx-font-size:16px;-fx-font-weight:bold;-fx-text-fill:#1f2937;");
        HBox row1 = new HBox(8, add, update);
        HBox row2 = new HBox(8, delete, clear);
        HBox correctRow = new HBox(8, new Label("Correct option:"), correct);
        correctRow.setAlignment(Pos.CENTER_LEFT);

        VBox form = new VBox(8, formTitle, qText, optBox, correctRow, row1, row2, back);
        form.setPrefWidth(320);
        form.setMinWidth(320);

        HBox body = new HBox(18, table, form);
        VBox.setVgrow(body, Priority.ALWAYS);

        Label pickLabel = formLabel("Questions for exam:");
        VBox card = Theme.card(Double.MAX_VALUE, Theme.title("Manage Questions"), pickLabel, examBox, body);
        card.setMaxHeight(Double.MAX_VALUE);
        show(card);
    }

    private Question readForm(TextArea qText, TextField[] opts, ComboBox<String> correct, String examId) {
        String text = qText.getText().trim();
        if (text.isEmpty()) {
            warn("Question text is required.");
            return null;
        }
        String[] o = new String[4];
        for (int i = 0; i < 4; i++) {
            o[i] = opts[i].getText().trim();
            if (o[i].isEmpty()) {
                warn("All four options are required.");
                return null;
            }
        }
        return new Question(text, o, correct.getSelectionModel().getSelectedIndex(), examId);
    }

    private void clearForm(TableView<Question> table, TextArea qText, TextField[] opts, ComboBox<String> correct) {
        table.getSelectionModel().clearSelection();
        qText.clear();
        for (TextField f : opts) f.clear();
        correct.getSelectionModel().selectFirst();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
