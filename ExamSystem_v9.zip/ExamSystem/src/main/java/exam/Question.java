package exam;

/** A single multiple-choice question with four options. */
public class Question {
    private String text;
    private String[] options;      // always 4 options
    private int correctIndex;      // 0..3
    private String examId;         // which exam this question belongs to

    public Question(String text, String[] options, int correctIndex, String examId) {
        this.text = text;
        this.options = options;
        this.correctIndex = correctIndex;
        this.examId = examId;
    }

    public String getText() { return text; }
    public String[] getOptions() { return options; }
    public int getCorrectIndex() { return correctIndex; }
    public String getExamId() { return examId; }

    public String getCorrectAnswerText() { return options[correctIndex]; }

    /** Serialise to one tab-separated line for file storage. */
    public String toLine() {
        return String.join("\t", clean(text), clean(options[0]), clean(options[1]),
                clean(options[2]), clean(options[3]), String.valueOf(correctIndex), examId);
    }

    /** Parse a line produced by toLine(); returns null if the line is malformed. */
    public static Question fromLine(String line) {
        String[] p = line.split("\t", -1);
        if (p.length != 6 && p.length != 7) return null;      // 6 columns = older files without an exam id
        try {
            int correct = Integer.parseInt(p[5].trim());
            if (correct < 0 || correct > 3) return null;
            String examId = (p.length == 7 && !p[6].isBlank()) ? p[6].trim() : Exam.DEFAULT_ID;
            return new Question(p[0], new String[]{p[1], p[2], p[3], p[4]}, correct, examId);
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private static String clean(String s) {
        return s.replace("\t", " ").replace("\r", " ").replace("\n", " ").trim();
    }
}
