package exam;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Appends every exam attempt to data/history.txt and reads them back. */
public class HistoryStore {
    private static final Path FILE = Paths.get("data", "history.txt");
    private static final Path STARTED = Paths.get("data", "started.txt");

    public void add(ExamResult r) {
        try {
            Files.createDirectories(FILE.getParent());
            Files.write(FILE, (r.toLine() + System.lineSeparator()).getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            System.err.println("Could not save history: " + e.getMessage());
        }
    }

    /** All attempts by all students (used by the administrator). */
    public List<ExamResult> loadAll() {
        List<ExamResult> list = new ArrayList<>();
        if (!Files.exists(FILE)) return list;
        try {
            for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
                if (line.isBlank()) continue;
                ExamResult r = ExamResult.fromLine(line);
                if (r != null) list.add(r);
            }
        } catch (IOException e) {
            System.err.println("Could not read history: " + e.getMessage());
        }
        return list;
    }

    /** Only the attempts made by one student. */
    public List<ExamResult> loadForUser(String username) {
        List<ExamResult> list = new ArrayList<>();
        for (ExamResult r : loadAll()) {
            if (r.getUsername().equalsIgnoreCase(username)) list.add(r);
        }
        return list;
    }

    /** The student's saved result for one exam, or null if there is none (the latest one if several). */
    public ExamResult findFor(String username, String examId) {
        ExamResult found = null;
        for (ExamResult r : loadForUser(username)) {
            if (r.getExamId().equals(examId)) found = r;
        }
        return found;
    }

    /**
     * Written the moment a student begins an exam, before the first question is shown. If the program is
     * killed or the power fails mid-exam there is then still a record, so the exam cannot be started again.
     * Returns false if the record could not be saved (the exam must not start in that case).
     */
    public boolean markStarted(String username, String examId) {
        try {
            Files.createDirectories(STARTED.getParent());
            String line = username + "\t" + examId + "\t" + java.time.LocalDateTime.now()
                    + System.lineSeparator();
            Files.write(STARTED, line.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            return true;
        } catch (IOException e) {
            System.err.println("Could not record exam start: " + e.getMessage());
            return false;
        }
    }

    public boolean hasStarted(String username, String examId) {
        return startedExamIds(username).contains(examId);
    }

    /** Ids of every exam this student has started. */
    public Set<String> startedExamIds(String username) {
        Set<String> ids = new HashSet<>();
        if (!Files.exists(STARTED)) return ids;
        try {
            for (String line : Files.readAllLines(STARTED, StandardCharsets.UTF_8)) {
                String[] p = line.split("\t", -1);
                if (p.length >= 2 && p[0].equalsIgnoreCase(username)) ids.add(p[1]);
            }
        } catch (IOException e) {
            System.err.println("Could not read started exams: " + e.getMessage());
        }
        return ids;
    }
}
