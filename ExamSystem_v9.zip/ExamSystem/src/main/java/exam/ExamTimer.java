package exam;

import javafx.application.Platform;

import java.util.function.IntConsumer;

/**
 * Countdown timer that runs on its own daemon thread (multithreading).
 * UI callbacks are marshalled onto the JavaFX Application Thread via Platform.runLater.
 */
public class ExamTimer {
    private final int totalSeconds;
    private final IntConsumer onTick;
    private final Runnable onFinish;
    private volatile boolean running;
    private Thread thread;

    public ExamTimer(int totalSeconds, IntConsumer onTick, Runnable onFinish) {
        this.totalSeconds = totalSeconds;
        this.onTick = onTick;
        this.onFinish = onFinish;
    }

    public void start() {
        running = true;
        thread = new Thread(() -> {
            int remaining = totalSeconds;
            while (running && remaining > 0) {
                final int r = remaining;
                Platform.runLater(() -> onTick.accept(r));
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    return;             // stopped manually: do not auto-submit
                }
                remaining--;
            }
            if (running) {              // reached zero naturally
                running = false;
                Platform.runLater(() -> {
                    onTick.accept(0);
                    onFinish.run();     // auto-submit
                });
            }
        }, "exam-timer");
        thread.setDaemon(true);
        thread.start();
    }

    public void stop() {
        running = false;
        if (thread != null) thread.interrupt();
    }
}
