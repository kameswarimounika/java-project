package exam;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

/** Exam settings controlled by the administrator, stored in data/settings.txt. */
public class ExamSettings {
    private static final Path FILE = Paths.get("data", "settings.txt");

    private int durationMinutes = 10;
    private int marksPerQuestion = 1;
    private double negativeMarks = 0;      // deducted for each wrong answer
    private int questionsPerExam = 0;      // 0 = use every question

    public ExamSettings() {
        load();
    }

    public int getDurationMinutes() { return durationMinutes; }
    public int getMarksPerQuestion() { return marksPerQuestion; }
    public double getNegativeMarks() { return negativeMarks; }
    public int getQuestionsPerExam() { return questionsPerExam; }

    public void update(int minutes, int marks, double negative, int questions) {
        this.durationMinutes = minutes;
        this.marksPerQuestion = marks;
        this.negativeMarks = negative;
        this.questionsPerExam = questions;
        save();
    }

    private void load() {
        if (!Files.exists(FILE)) return;
        try {
            for (String line : Files.readAllLines(FILE, StandardCharsets.UTF_8)) {
                int eq = line.indexOf('=');
                if (eq < 0) continue;
                String key = line.substring(0, eq).trim();
                String val = line.substring(eq + 1).trim();
                try {
                    switch (key) {
                        case "durationMinutes" -> durationMinutes = Math.max(1, Integer.parseInt(val));
                        case "marksPerQuestion" -> marksPerQuestion = Math.max(1, Integer.parseInt(val));
                        case "negativeMarks" -> negativeMarks = Math.max(0, Double.parseDouble(val));
                        case "questionsPerExam" -> questionsPerExam = Math.max(0, Integer.parseInt(val));
                        default -> { }
                    }
                } catch (NumberFormatException ignored) {
                    // keep the default for this setting
                }
            }
        } catch (IOException e) {
            System.err.println("Could not read settings: " + e.getMessage());
        }
    }

    private void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.write(FILE, List.of(
                    "durationMinutes=" + durationMinutes,
                    "marksPerQuestion=" + marksPerQuestion,
                    "negativeMarks=" + negativeMarks,
                    "questionsPerExam=" + questionsPerExam), StandardCharsets.UTF_8);
        } catch (IOException e) {
            System.err.println("Could not save settings: " + e.getMessage());
        }
    }
}
