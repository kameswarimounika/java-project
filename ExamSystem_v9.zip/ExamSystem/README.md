# Smart Online Examination and Evaluation System (PS-04)

JavaFX desktop app with student and admin login, admin-controlled exam timer,
automatic evaluation, and all data stored in plain text files (no database).

## Run (Windows)
Double-click `run.bat`. It compiles everything and starts the app.
If your JavaFX SDK is in a different folder, edit the `JFX=` line in `run.bat`.

Or from Command Prompt inside this folder:

    dir /s /b src\*.java > sources.txt
    javac --module-path "<JAVAFX_LIB>" --add-modules javafx.controls -d out @sources.txt
    java --module-path "<JAVAFX_LIB>" --add-modules javafx.controls -cp out exam.MainApp

Maven users: `mvn javafx:run`.

## Logins
- First run: there is NO default password. The app asks you to create the administrator account.
- Later runs: choose "Administrator" or "Student" on the login screen.
- Students: click "New student? Register here".
- Forgot password: use the security question set at registration.

## New in v9: multiple exams and a student dashboard
- The administrator creates any number of exams (**Manage Exams**): title, subject, type, faculty name,
  its own time limit, marking rules, number of questions, and an optional "opens at / closes at" window.
- Every question belongs to one exam (**Manage Questions** -> pick the exam at the top).
- The student's home screen is a dashboard of exam cards (type, subject, title, status, minutes, number of
  questions, faculty). An open exam shows **Start**; an exam already written shows **Review** (with the score);
  not-yet-open / closed / interrupted exams show a disabled button. Filters: All / To do / Past.
- **Each exam can be written only once per student.** The attempt is recorded in `data/started.txt` before the
  first question appears, so closing the window, a crash or a power cut cannot give a second attempt.
  (If that happens the card shows "Attempt interrupted"; to allow a retake, delete that student's line for the
  exam from `data/started.txt`.)
- Results and the CSV export now include the exam name.
- Upgrading from v8: copy your old `data` folder next to the program. Your old settings, questions and results
  become the exam "General Exam"; students who already wrote it will see it as completed.

## Features added in v8
- Administrator can add other administrators, reset passwords and delete accounts (Manage Users and Admins)
- Exam settings: time, marks per correct answer, negative marking, questions per exam (random subset)
- Options are shuffled for every student; closing the window mid-exam submits the exam
- Result screen with pie chart and a full answer review
- Admin results screen: search by name and export to CSV

## Requirement mapping
| # | Requirement | Where |
|---|-------------|-------|
| 1 | Admin adds/manages MCQs | `MainApp.showAdmin()`, `QuestionBank` |
| 2 | Questions with options | `MainApp.renderQuestion()` |
| 3 | Next / Previous / Submit | `MainApp.buildExamScene()` + question navigator |
| 4 | Countdown timer (set by admin) | `ExamTimer` thread, `ExamSettings`, `MainApp.showSettings()` |
| 5 | Auto-submit on expiry | `ExamTimer` -> `MainApp.finishExam(true)` |
| 6 | Marks calculation | `MainApp.finishExam()` (1 mark per correct answer) |
| 7 | Result, percentage, status | `ExamResult`, `MainApp.showResult()` |
| 8 | History via file handling | `HistoryStore` -> `data/history.txt` |
| + | Login / security | `User`, `UserStore` -> `data/users.txt` (salted PBKDF2 hashes, lockout after 3 wrong attempts, security-question reset, password rules) |
| + | Visual effects | `Theme` (animated blurred background, drop shadows, fades, hover scale, pulsing timer) |

Status bands: >=80 Excellent, >=60 Good, >=40 Pass, else Fail.

## Data files (created automatically in `data/`)
- `exams.txt`, `questions.txt`, `history.txt`, `started.txt`, `users.txt`, `exams.seq`
- `settings.txt` is only read once (v8 upgrade) and is no longer used afterwards
