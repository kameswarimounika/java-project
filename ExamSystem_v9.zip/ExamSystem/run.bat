@echo off
rem Edit the next line if your JavaFX "lib" folder is somewhere else
set JFX=C:\Users\bindh\Downloads\openjfx-21.0.13_windows-x64_bin-sdk\javafx-sdk-21.0.13\lib

cd /d "%~dp0"
if exist out rmdir /s /q out
dir /s /b src\*.java > sources.txt

javac -encoding UTF-8 --module-path "%JFX%" --add-modules javafx.controls -d out @sources.txt
if errorlevel 1 (
    echo.
    echo Compile failed. Copy the error above and send it for help.
    pause
    exit /b 1
)

java --module-path "%JFX%" --add-modules javafx.controls -cp out exam.MainApp
pause
